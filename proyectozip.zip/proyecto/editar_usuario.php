<?php
session_start();
require 'db_connect.php';
require 'layout_header.php';

// Verificar si el usuario está autenticado y es admin
if (!isset($_SESSION['user_id']) || $_SESSION['tipo'] != 'admin') {
    header('Location: login.php');
    exit;
}

$error = '';
$success = '';
$usuario = null;

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
    $stmt->execute([$id]);
    $usuario = $stmt->fetch();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'] ?? '';
    $username = $_POST['username'] ?? '';
    $email = $_POST['email'] ?? '';
    $tipo = $_POST['tipo'] ?? '';
    $password = $_POST['password'] ?? '';

    if (empty($id) || empty($username) || empty($email) || empty($tipo)) {
        $error = "Todos los campos son obligatorios, excepto la contraseña si no desea cambiarla.";
    } else {
        if (!empty($password)) {
            $stmt = $pdo->prepare("UPDATE usuarios SET username = ?, email = ?, password = ?, tipo = ? WHERE id = ?");
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $result = $stmt->execute([$username, $email, $hashed_password, $tipo, $id]);
        } else {
            $stmt = $pdo->prepare("UPDATE usuarios SET username = ?, email = ?, tipo = ? WHERE id = ?");
            $result = $stmt->execute([$username, $email, $tipo, $id]);
        }

        if ($result) {
            $success = "Usuario actualizado exitosamente.";
            // Actualizar la información del usuario después de la edición
            $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
            $stmt->execute([$id]);
            $usuario = $stmt->fetch();
        } else {
            $error = "Error al actualizar el usuario.";
        }
    }
}

// Render header
renderHeader('Editar Usuario');
?>

<main class="main-content">
    <div class="container">
        <h1>Editar Usuario</h1>
        
        <?php if ($error): ?>
            <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="success-message"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        
        <?php if ($usuario): ?>
            <form method="POST" action="editar_usuario.php" class="form-contrato">
                <input type="hidden" name="id" value="<?php echo htmlspecialchars($usuario['id']); ?>">
                
                <div class="form-group">
                    <label for="username">Nombre de Usuario:</label>
                    <input type="text" id="username" name="username" required class="form-input" value="<?php echo htmlspecialchars($usuario['username']); ?>">
                </div>
                
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required class="form-input" value="<?php echo htmlspecialchars($usuario['email']); ?>">
                </div>
                
                <div class="form-group">
                    <label for="password">Nueva Contraseña (dejar en blanco para no cambiar):</label>
                    <input type="password" id="password" name="password" class="form-input">
                </div>
                
                <div class="form-group">
                    <label for="tipo">Tipo de Usuario:</label>
                    <select id="tipo" name="tipo" required class="form-input">
                        <option value="admin" <?php echo $usuario['tipo'] == 'admin' ? 'selected' : ''; ?>>Admin</option>
                        <option value="rh" <?php echo $usuario['tipo'] == 'rh' ? 'selected' : ''; ?>>RH</option>
                        <option value="usuario" <?php echo $usuario['tipo'] == 'usuario' ? 'selected' : ''; ?>>Usuario Regular</option>
                    </select>
                </div>
                
                <button type="submit" class="btn btn-primary">Actualizar Usuario</button>
            </form>
        <?php else: ?>
            <p>Usuario no encontrado.</p>
        <?php endif; ?>
        
        <a href="admin_usuarios.php" class="btn btn-secondary mt-3">Volver a la lista de usuarios</a>
    </div>
</main>

<?php include 'layout_footer.php'; ?>

