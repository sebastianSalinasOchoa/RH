<?php
session_start();
require 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['tipo'] != 'rh') {
    header('Location: index.php');
    exit;
}

$query = 'SELECT s.*, u.username, u.empresa, u.telefono, u.email, v.estrellas, v.comentario 
          FROM solicitudes s 
          JOIN usuarios u ON s.cliente_id = u.id 
          LEFT JOIN valoraciones v ON s.id = v.solicitud_id 
          WHERE s.estado = "finalizada" 
          ORDER BY s.fecha_creacion DESC';

$stmt = $pdo->query($query);
$solicitudes = $stmt->fetchAll();

function obtenerTrabajadoresAsignados($pdo, $solicitud_id) {
    $stmt = $pdo->prepare('SELECT t.id, t.nombre FROM trabajadores t JOIN asignaciones a ON t.id = a.trabajador_id WHERE a.solicitud_id = ?');
    $stmt->execute([$solicitud_id]);
    return $stmt->fetchAll();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Solicitudes Finalizadas</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Solicitudes Finalizadas</h1>
        
        <?php foreach ($solicitudes as $solicitud): ?>
            <div class="solicitud">
                <h2>Solicitud #<?php echo $solicitud['id']; ?></h2>
                <p><strong>Cliente:</strong> <?php echo htmlspecialchars($solicitud['username']); ?></p>
                <p><strong>Empresa:</strong> <?php echo htmlspecialchars($solicitud['empresa']); ?></p>
                <p><strong>Teléfono:</strong> <?php echo htmlspecialchars($solicitud['telefono']); ?></p>
                <p><strong>Email:</strong> <?php echo htmlspecialchars($solicitud['email']); ?></p>
                <p><strong>Descripción:</strong> <?php echo htmlspecialchars($solicitud['descripcion']); ?></p>
                <p><strong>Fecha de creación:</strong> <?php echo $solicitud['fecha_creacion']; ?></p>
                
                <?php $trabajadores_asignados = obtenerTrabajadoresAsignados($pdo, $solicitud['id']); ?>
                <?php if (!empty($trabajadores_asignados)): ?>
                    <p><strong>Trabajadores asignados:</strong></p>
                    <ul>
                        <?php foreach ($trabajadores_asignados as $trabajador): ?>
                            <li><?php echo htmlspecialchars($trabajador['nombre']); ?></li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
                
                <div class="valoracion">
                    <h3>Valoración del cliente</h3>
                    <p><strong>Estrellas:</strong> <?php echo $solicitud['estrellas']; ?>/5</p>
                    <p><strong>Comentario:</strong> <?php echo htmlspecialchars($solicitud['comentario']); ?></p>
                </div>
            </div>
        <?php endforeach; ?>
        <a href="index.php">Volver al inicio</a>
    </div>
</body>
</html>

