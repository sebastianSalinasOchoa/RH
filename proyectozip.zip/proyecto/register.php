<?php
session_start();
require 'db_connect.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $tipo = 'rh'; // Por defecto, registramos como usuario RH

    if ($password !== $confirm_password) {
        $error = 'Las contraseñas no coinciden';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE username = ? OR email = ?");
        $stmt->execute([$username, $email]);
        if ($stmt->rowCount() > 0) {
            $error = 'El usuario o email ya existe';
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO usuarios (username, email, password, tipo) VALUES (?, ?, ?, ?)");
            if ($stmt->execute([$username, $email, $hashed_password, $tipo])) {
                $success = 'Usuario registrado con éxito. Ahora puedes iniciar sesión.';
            } else {
                $error = 'Error al registrar el usuario';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro - Servicios Expenic</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body class="register-page">
    <div class="auth-container">
        <div class="auth-logo">
            <img src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-7iWXMQo4nxg0caC9kuKxjIvUAoVJW4.png" alt="Servicios Expenic Logo" class="logo">
        </div>
        <h2>Registro de Usuario</h2>
        <?php if ($error): ?>
            <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="success-message"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        <form class="auth-form" method="POST">
            <div class="form-group">
                <label for="username" class="form-label">
                    <i class="fas fa-user"></i> Usuario:
                </label>
                <input type="text" id="username" name="username" required class="form-input">
            </div>
            <div class="form-group">
                <label for="email" class="form-label">
                    <i class="fas fa-envelope"></i> Email:
                </label>
                <input type="email" id="email" name="email" required class="form-input">
            </div>
            <div class="form-group">
                <label for="password" class="form-label">
                    <i class="fas fa-lock"></i> Contraseña:
                </label>
                <input type="password" id="password" name="password" required class="form-input">
            </div>
            <div class="form-group">
                <label for="confirm_password" class="form-label">
                    <i class="fas fa-lock"></i> Confirmar Contraseña:
                </label>
                <input type="password" id="confirm_password" name="confirm_password" required class="form-input">
            </div>
            <button type="submit" class="btn btn-primary">Registrarse</button>
        </form>
        <div class="auth-links">
            <a href="login.php">¿Ya tienes una cuenta? Inicia sesión</a>
        </div>
    </div>
</body>
</html>

