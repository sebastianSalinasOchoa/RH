</main>
    <footer class="bg-light py-3 mt-5">
        <div class="container text-center">
            <p>&copy; <?php echo date("Y"); ?> Sistema de Gestión de Contratos</p>
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

