<?php
session_start();
require 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['tipo'] != 'rh') {
    header('Location: index.php');
    exit;
}

$busqueda = isset($_GET['busqueda']) ? $_GET['busqueda'] : '';
$filtro = isset($_GET['filtro']) ? $_GET['filtro'] : 'todos';
$estado_filtro = isset($_GET['estado']) ? $_GET['estado'] : 'todos';

$query = 'SELECT * FROM trabajadores WHERE 1=1';
$params = [];

if (!empty($busqueda)) {
    $query .= ' AND (nombre LIKE :busqueda OR cedula LIKE :busqueda)';
    $params[':busqueda'] = "%$busqueda%";
}

if ($filtro !== 'todos') {
    $query .= ' AND especialidad = :filtro';
    $params[':filtro'] = $filtro;
}

if ($estado_filtro != 'todos') {
    $query .= ' AND estado = :estado';
    $params[':estado'] = $estado_filtro;
}

$query .= ' ORDER BY nombre';

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$trabajadores = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Obtener todas las especialidades para el filtro
$stmtEspecialidades = $pdo->query('SELECT DISTINCT especialidad FROM trabajadores ORDER BY especialidad');
$especialidades = $stmtEspecialidades->fetchAll(PDO::FETCH_COLUMN);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listado de Trabajadores - Sistema de Coordinación</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="layout">
        <aside class="sidebar">
            <h1 class="text-center mb-4">Sistema RH</h1>
            <nav>
                <ul class="nav-menu">
                    <li class="nav-item">
                        <a href="dashboard.php" class="nav-link">
                            <i class="fas fa-tachometer-alt"></i> Panel de Control
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="gestionar_solicitudes.php" class="nav-link">
                            <i class="fas fa-tasks"></i> Gestionar Solicitudes
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="agregar_solicitud.php" class="nav-link">
                            <i class="fas fa-plus-circle"></i> Agregar Solicitud
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="gestionar_clientes.php" class="nav-link">
                            <i class="fas fa-users"></i> Gestionar Clientes
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="gestionar_trabajadores.php" class="nav-link">
                            <i class="fas fa-hard-hat"></i> Gestionar Trabajadores
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="listar_trabajadores.php" class="nav-link">
                            <i class="fas fa-list"></i> Listado de Trabajadores
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="reportes_analisis.php" class="nav-link">
                            <i class="fas fa-chart-bar"></i> Reportes y Análisis
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="reporte_diario.php" class="nav-link">
                            <i class="fas fa-calendar-day"></i> Reporte Diario
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="logout.php" class="nav-link">
                            <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>
        <main class="main-content">
            <div class="container">
                <h2>Listado de Trabajadores</h2>
                
                <div class="card mb-4">
                    <form method="GET" class="form-busqueda">
                        <div class="form-group">
                            <input type="text" name="busqueda" class="form-input" placeholder="Buscar por nombre o cédula" value="<?php echo htmlspecialchars($busqueda); ?>">
                        </div>
                        <div class="form-group">
                            <select name="filtro" class="form-input">
                                <option value="todos" <?php echo $filtro === 'todos' ? 'selected' : ''; ?>>Todas las especialidades</option>
                                <?php foreach ($especialidades as $especialidad): ?>
                                    <option value="<?php echo htmlspecialchars($especialidad); ?>" <?php echo $filtro === $especialidad ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($especialidad); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <select name="estado" class="form-input">
                                <option value="todos" <?php echo $estado_filtro === 'todos' ? 'selected' : ''; ?>>Todos los estados</option>
                                <option value="habilitado" <?php echo $estado_filtro === 'habilitado' ? 'selected' : ''; ?>>Habilitados</option>
                                <option value="deshabilitado" <?php echo $estado_filtro === 'deshabilitado' ? 'selected' : ''; ?>>Deshabilitados</option>
                            </select>
                        </div>
                        <button type="submit" class="btn">Buscar</button>
                    </form>
                </div>

                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Nombre</th>
                                <th>Email</th>
                                <th>Teléfono</th>
                                <th>Cédula</th>
                                <th>Especialidad</th>
                                <th>Experiencia</th>
                                <th>Habilidades</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($trabajadores as $trabajador): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($trabajador['nombre']); ?></td>
                                    <td><?php echo htmlspecialchars($trabajador['email'] ?? ''); ?></td>
                                    <td><?php echo htmlspecialchars($trabajador['telefono'] ?? ''); ?></td>
                                    <td><?php echo htmlspecialchars($trabajador['cedula'] ?? ''); ?></td>
                                    <td><?php echo htmlspecialchars($trabajador['especialidad'] ?? ''); ?></td>
                                    <td><?php echo $trabajador['experiencia'] ? htmlspecialchars($trabajador['experiencia']) . ' años' : ''; ?></td>
                                    <td><?php echo htmlspecialchars($trabajador['habilidades'] ?? ''); ?></td>
                                    <td><?php echo htmlspecialchars($trabajador['estado']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</body>
</html>







