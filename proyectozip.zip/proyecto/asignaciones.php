<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include 'db_connect.php';

function enviarMensajeCoordinacion($cliente_id, $trabajador_id, $fecha_inicio, $fecha_fin, $tarea) {
    global $conn;
    
    // Obtener información del cliente
    $stmt = $conn->prepare("SELECT nombre_empresa, contacto FROM clientes WHERE id = ?");
    $stmt->bind_param("i", $cliente_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $cliente = $result->fetch_assoc();

    // Obtener información del trabajador
    $stmt = $conn->prepare("SELECT nombre, contacto FROM trabajadores WHERE id = ?");
    $stmt->bind_param("i", $trabajador_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $trabajador = $result->fetch_assoc();

    // Mensaje para el cliente
    $mensaje_cliente = "Estimado/a {$cliente['nombre_empresa']},\n\n";
    $mensaje_cliente .= "Se ha asignado al trabajador {$trabajador['nombre']} para la tarea:\n";
    $mensaje_cliente .= "Tarea: $tarea\n";
    $mensaje_cliente .= "Fecha de inicio: $fecha_inicio\n";
    $mensaje_cliente .= "Fecha de fin: $fecha_fin\n\n";
    $mensaje_cliente .= "Por favor, contacte al trabajador si necesita más información.";

    // Mensaje para el trabajador
    $mensaje_trabajador = "Estimado/a {$trabajador['nombre']},\n\n";
    $mensaje_trabajador .= "Se le ha asignado una nueva tarea para {$cliente['nombre_empresa']}:\n";
    $mensaje_trabajador .= "Tarea: $tarea\n";
    $mensaje_trabajador .= "Fecha de inicio: $fecha_inicio\n";
    $mensaje_trabajador .= "Fecha de fin: $fecha_fin\n\n";
    $mensaje_trabajador .= "Por favor, contacte al cliente si necesita más información.";

    // Enviar correos (esto es un ejemplo, necesitarás configurar un servidor de correo)
    mail($cliente['contacto'], "Nueva asignación de trabajador", $mensaje_cliente);
    mail($trabajador['contacto'], "Nueva tarea asignada", $mensaje_trabajador);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $cliente_id = $_POST['cliente_id'];
                $trabajador_id = $_POST['trabajador_id'];
                $fecha_inicio = $_POST['fecha_inicio'];
                $fecha_fin = $_POST['fecha_fin'];
                $tarea = $_POST['tarea'];
                $stmt = $conn->prepare("INSERT INTO asignaciones (cliente_id, trabajador_id, fecha_inicio, fecha_fin, tarea) VALUES (?, ?, ?, ?, ?)");
                $stmt->bind_param("iisss", $cliente_id, $trabajador_id, $fecha_inicio, $fecha_fin, $tarea);
                $stmt->execute();
                enviarMensajeCoordinacion($cliente_id, $trabajador_id, $fecha_inicio, $fecha_fin, $tarea);
                break;
            case 'edit':
                $id = $_POST['id'];
                $cliente_id = $_POST['cliente_id'];
                $trabajador_id = $_POST['trabajador_id'];
                $fecha_inicio = $_POST['fecha_inicio'];
                $fecha_fin = $_POST['fecha_fin'];
                $tarea = $_POST['tarea'];
                $stmt = $conn->prepare("UPDATE asignaciones SET cliente_id = ?, trabajador_id = ?, fecha_inicio = ?, fecha_fin = ?, tarea = ? WHERE id = ?");
                $stmt->bind_param("iisssi", $cliente_id, $trabajador_id, $fecha_inicio, $fecha_fin, $tarea, $id);
                $stmt->execute();
                break;
            case 'delete':
                $id = $_POST['id'];
                $stmt = $conn->prepare("DELETE FROM asignaciones WHERE id = ?");
                $stmt->bind_param("i", $id);
                $stmt->execute();
                break;
        }
    }
}

$search = isset($_GET['search']) ? $_GET['search'] : '';
$query = "SELECT a.*, c.nombre_empresa, t.nombre AS nombre_trabajador 
          FROM asignaciones a 
          JOIN clientes c ON a.cliente_id = c.id 
          JOIN trabajadores t ON a.trabajador_id = t.id 
          WHERE c.nombre_empresa LIKE ? OR t.nombre LIKE ?";
$search_param = "%$search%";
$stmt = $conn->prepare($query);
$stmt->bind_param("ss", $search_param, $search_param);
$stmt->execute();
$result = $stmt->get_result();

$clientes = $conn->query("SELECT id, nombre_empresa FROM clientes");
$trabajadores = $conn->query("SELECT id, nombre FROM trabajadores");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Asignaciones</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Gestión de Asignaciones</h1>
    <form method="get" class="search-form">
        <input type="text" name="search" placeholder="Buscar asignaciones" value="<?php echo htmlspecialchars($search); ?>">
        <input type="submit" value="Buscar">
    </form>
    <form method="post" id="asignacionForm">
        <input type="hidden" name="action" value="add">
        <input type="hidden" name="id" id="editId">
        <select name="cliente_id" required>
            <option value="">Seleccione un cliente</option>
            <?php while($cliente = $clientes->fetch_assoc()): ?>
                <option value="<?php echo $cliente['id']; ?>"><?php echo htmlspecialchars($cliente['nombre_empresa']); ?></option>
            <?php endwhile; ?>
        </select>
        <select name="trabajador_id" required>
            <option value="">Seleccione un trabajador</option>
            <?php while($trabajador = $trabajadores->fetch_assoc()): ?>
                <option value="<?php echo $trabajador['id']; ?>"><?php echo htmlspecialchars($trabajador['nombre']); ?></option>
            <?php endwhile; ?>
        </select>
        <input type="date" name="fecha_inicio" required>
        <input type="date" name="fecha_fin" required>
        <textarea name="tarea" placeholder="Descripción de la tarea"></textarea>
        <input type="submit" value="Agregar Asignación" id="submitBtn">
    </form>
    <table>
        <tr>
            <th>Cliente</th>
            <th>Trabajador</th>
            <th>Fecha Inicio</th>
            <th>Fecha Fin</th>
            <th>Tarea</th>
            <th>Acciones</th>
        </tr>
        <?php while($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?php echo htmlspecialchars($row['nombre_empresa']); ?></td>
            <td><?php echo htmlspecialchars($row['nombre_trabajador']); ?></td>
            <td><?php echo htmlspecialchars($row['fecha_inicio']); ?></td>
            <td><?php echo htmlspecialchars($row['fecha_fin']); ?></td>
            <td><?php echo htmlspecialchars($row['tarea']); ?></td>
            <td>
                <button onclick="editAsignacion(<?php echo $row['id']; ?>, <?php echo $row['cliente_id']; ?>, <?php echo $row['trabajador_id']; ?>, '<?php echo $row['fecha_inicio']; ?>', '<?php echo $row['fecha_fin']; ?>', '<?php echo addslashes($row['tarea']); ?>')">Editar</button>
                <form method="post" style="display:inline;">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                    <input type="submit" value="Eliminar" onclick="return confirm('¿Estás seguro de que quieres eliminar esta asignación?');">
                </form>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
    <a href="index.php">Volver al Panel de Control</a>
    <script>
    function editAsignacion(id, cliente_id, trabajador_id, fecha_inicio, fecha_fin, tarea) {
        document.getElementById('editId').value = id;
        document.getElementsByName('cliente_id')[0].value = cliente_id;
        document.getElementsByName('trabajador_id')[0].value = trabajador_id;
        document.getElementsByName('fecha_inicio')[0].value = fecha_inicio;
        document.getElementsByName('fecha_fin')[0].value = fecha_fin;
        document.getElementsByName('tarea')[0].value = tarea;
        document.getElementsByName('action')[0].value = 'edit';
        document.getElementById('submitBtn').value = 'Actualizar Asignación';
    }
    </script>
</body>
</html>