<?php
// Configuración de la base de datos
$host = 'localhost';  // Normalmente 'localhost' si la base de datos está en el mismo servidor
$dbname = 'sistema_rh';  // El nombre de tu base de datos
$username = 'root';  // Tu nombre de usuario de MySQL
$password = '';  // Tu contraseña de MySQL

// Opciones de PDO para manejar errores y configurar el modo de recuperación
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    // Crear una nueva conexión PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password, $options);
} catch (PDOException $e) {
    // En caso de error, terminar el script y mostrar el mensaje de error
    die("Error de conexión: " . $e->getMessage());
}

