<?php
session_start();
require 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['tipo'] != 'rh') {
    header('Location: index.php');
    exit;
}

// Obtener la fecha actual
$fecha_actual = date('Y-m-d');

// Consulta para obtener los trabajadores asignados hoy, los clientes y el conteo
$query = "
SELECT 
    c.nombre_empresa AS cliente,
    COUNT(DISTINCT a.trabajador_id) AS num_trabajadores,
    GROUP_CONCAT(DISTINCT t.nombre ORDER BY t.nombre ASC SEPARATOR ', ') AS trabajadores
FROM 
    asignaciones a
JOIN 
    solicitudes s ON a.solicitud_id = s.id
JOIN 
    clientes c ON s.cliente_id = c.id
JOIN 
    trabajadores t ON a.trabajador_id = t.id
WHERE 
    a.fecha_asignacion = :fecha_actual
GROUP BY 
    c.id
ORDER BY 
    c.nombre_empresa
";

$stmt = $pdo->prepare($query);
$stmt->execute(['fecha_actual' => $fecha_actual]);
$asignaciones = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Obtener el total de trabajadores asignados hoy
$query_total = "
SELECT COUNT(DISTINCT trabajador_id) AS total_trabajadores
FROM asignaciones
WHERE fecha_asignacion = :fecha_actual
";

$stmt_total = $pdo->prepare($query_total);
$stmt_total->execute(['fecha_actual' => $fecha_actual]);
$total_trabajadores = $stmt_total->fetch(PDO::FETCH_ASSOC)['total_trabajadores'];

// Obtener todos los trabajadores asignados hoy con detalles
$query_trabajadores = "
SELECT 
    t.nombre AS trabajador,
    c.nombre_empresa AS cliente,
    s.descripcion AS descripcion_solicitud
FROM 
    asignaciones a
JOIN 
    trabajadores t ON a.trabajador_id = t.id
JOIN 
    solicitudes s ON a.solicitud_id = s.id
JOIN 
    clientes c ON s.cliente_id = c.id
WHERE 
    a.fecha_asignacion = :fecha_actual
ORDER BY 
    t.nombre ASC
";

$stmt_trabajadores = $pdo->prepare($query_trabajadores);
$stmt_trabajadores->execute(['fecha_actual' => $fecha_actual]);
$trabajadores_asignados = $stmt_trabajadores->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reporte Diario - Sistema de Coordinación</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="layout">
        <aside class="sidebar">
            <h1 class="text-center mb-4">Sistema RH</h1>
            <nav>
                <ul class="nav-menu">
                    <li class="nav-item">
                        <a href="dashboard.php" class="nav-link">
                            <i class="fas fa-tachometer-alt"></i> Panel de Control
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="gestionar_solicitudes.php" class="nav-link">
                            <i class="fas fa-tasks"></i> Gestionar Solicitudes
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="agregar_solicitud.php" class="nav-link">
                            <i class="fas fa-plus-circle"></i> Agregar Solicitud
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="gestionar_clientes.php" class="nav-link">
                            <i class="fas fa-users"></i> Gestionar Clientes
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="gestionar_trabajadores.php" class="nav-link">
                            <i class="fas fa-hard-hat"></i> Gestionar Trabajadores
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="gestionar_contratos.php" class="nav-link">
                            <i class="fas fa-file-contract"></i> Gestionar Contratos
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="listar_trabajadores.php" class="nav-link">
                            <i class="fas fa-list"></i> Listado de Trabajadores
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="reportes_analisis.php" class="nav-link">
                            <i class="fas fa-chart-bar"></i> Reportes y Análisis
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="reporte_diario.php" class="nav-link">
                            <i class="fas fa-calendar-day"></i> Reporte Diario
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="logout.php" class="nav-link">
                            <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>
        <main class="main-content">
            <div class="container">
                <h2>Reporte Diario - <?php echo date('d/m/Y', strtotime($fecha_actual)); ?></h2>
                
                <div class="dashboard-stats">
                    <div class="stat-card">
                        <h3>Total Trabajadores Asignados Hoy</h3>
                        <p><?php echo $total_trabajadores; ?></p>
                    </div>
                </div>

                <div class="card mb-4">
                    <h3>Asignaciones por Cliente</h3>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Cliente</th>
                                    <th>Número de Trabajadores</th>
                                    <th>Trabajadores Asignados</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($asignaciones as $asignacion): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($asignacion['cliente']); ?></td>
                                        <td><?php echo $asignacion['num_trabajadores']; ?></td>
                                        <td><?php echo htmlspecialchars($asignacion['trabajadores']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="card mb-4">
                    <h3>Detalle de Trabajadores Asignados Hoy</h3>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Trabajador</th>
                                    <th>Cliente</th>
                                    <th>Descripción de la Solicitud</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($trabajadores_asignados as $trabajador): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($trabajador['trabajador']); ?></td>
                                        <td><?php echo htmlspecialchars($trabajador['cliente']); ?></td>
                                        <td><?php echo htmlspecialchars($trabajador['descripcion_solicitud']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>
</body>
</html>




