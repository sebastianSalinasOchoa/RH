<?php
session_start();
//error_log("Session data: " . print_r($_SESSION, true));
if (!isset($_SESSION['user_id'])) {
  //error_log("user_id no está establecido en la sesión");
} elseif ($_SESSION['tipo'] != 'rh' && $_SESSION['tipo'] != 'admin') {
  //error_log("Tipo de usuario no autorizado: " . $_SESSION['tipo']);
}
require_once 'db_connect.php';
require_once 'layout_header.php';

// Verificar si el usuario está autenticado y tiene los permisos necesarios
if (!isset($_SESSION['user_id']) || ($_SESSION['tipo'] != 'rh' && $_SESSION['tipo'] != 'admin')) {
  header('Location: login.php');
  exit;
}

// Función para registrar errores
function logError($message) {
  error_log(date('[Y-m-d H:i:s] ') . "Error en gestionar_solicitudes.php: " . $message . "\n", 3, "error.log");
}

// Función para obtener las columnas de una tabla
function getTableColumns($pdo, $tableName) {
  $stmt = $pdo->query("DESCRIBE $tableName");
  return $stmt->fetchAll(PDO::FETCH_COLUMN);
}

// Obtener la estructura de las tablas
$solicitudesColumns = getTableColumns($pdo, 'solicitudes');
$clientesColumns = getTableColumns($pdo, 'clientes');
$usuariosColumns = getTableColumns($pdo, 'usuarios');

//logError("Columnas de solicitudes: " . implode(", ", $solicitudesColumns));
//logError("Columnas de usuarios: " . implode(", ", $usuariosColumns));
//logError("Columnas de clientes: " . implode(", ", $clientesColumns));

// Construir la consulta SQL basada en las columnas existentes
$select_columns = ['s.id'];
if (in_array('fecha_solicitud', $solicitudesColumns)) $select_columns[] = 's.fecha_solicitud';
if (in_array('estado', $solicitudesColumns)) $select_columns[] = 's.estado';
if (in_array('descripcion', $solicitudesColumns)) $select_columns[] = 's.descripcion';

// Columnas de clientes
$clienteNombreColumn = in_array('nombre', $clientesColumns) ? 'nombre' : (in_array('nombre_cliente', $clientesColumns) ? 'nombre_cliente' : null);
if ($clienteNombreColumn) $select_columns[] = "c.$clienteNombreColumn AS nombre_cliente";
if (in_array('empresa', $clientesColumns)) $select_columns[] = 'c.empresa';

// Columnas de usuarios
$usuarioNombreColumn = null;
foreach (['nombre', 'username', 'user', 'email'] as $possibleColumn) {
  if (in_array($possibleColumn, $usuariosColumns)) {
      $usuarioNombreColumn = $possibleColumn;
      break;
  }
}

if ($usuarioNombreColumn) {
  $select_columns[] = "u.$usuarioNombreColumn AS nombre_encargado";
} else {
  $select_columns[] = "u.id AS id_encargado";
}

// Construir la consulta base
$query = "SELECT " . implode(', ', $select_columns) . " FROM solicitudes s";

// Agregar JOIN con clientes si existe la columna cliente_id
if (in_array('cliente_id', $solicitudesColumns)) {
  $query .= " LEFT JOIN clientes c ON s.cliente_id = c.id";
}

// Agregar JOIN con usuarios si existe la columna encargado_id
if (in_array('encargado_id', $solicitudesColumns)) {
  $query .= " LEFT JOIN usuarios u ON s.encargado_id = u.id";
}

$query .= " ORDER BY s.id DESC";

//logError("Query construida: " . $query);

try {
  $stmt = $pdo->prepare($query);
  $stmt->execute();
  $solicitudes = $stmt->fetchAll(PDO::FETCH_ASSOC);
  //logError("Número de solicitudes recuperadas: " . count($solicitudes));
} catch (PDOException $e) {
  //logError("Error en la consulta: " . $e->getMessage());
  die("Error en la consulta: " . $e->getMessage());
}

renderHeader('Gestionar Solicitudes');
?>

<div class="container">
  <h2>Gestionar Solicitudes</h2>
  
  <?php if (empty($solicitudes)): ?>
      <p>No se encontraron solicitudes.</p>
  <?php else: ?>
  <table class="table">
      <thead>
          <tr>
              <th>ID</th>
              <?php if (in_array('fecha_solicitud', $solicitudesColumns)): ?>
              <th>Fecha</th>
              <?php endif; ?>
              <?php if ($clienteNombreColumn): ?>
              <th>Cliente</th>
              <?php endif; ?>
              <?php if (in_array('empresa', $clientesColumns)): ?>
              <th>Empresa</th>
              <?php endif; ?>
              <th>Encargado</th>
              <?php if (in_array('estado', $solicitudesColumns)): ?>
              <th>Estado</th>
              <?php endif; ?>
              <?php if (in_array('descripcion', $solicitudesColumns)): ?>
              <th>Descripción</th>
              <?php endif; ?>
              <th>Acciones</th>
          </tr>
      </thead>
      <tbody>
          <?php foreach ($solicitudes as $solicitud): ?>
          <tr>
              <td><?php echo htmlspecialchars($solicitud['id']); ?></td>
              <?php if (isset($solicitud['fecha_solicitud'])): ?>
              <td><?php echo htmlspecialchars($solicitud['fecha_solicitud']); ?></td>
              <?php endif; ?>
              <?php if (isset($solicitud['nombre_cliente'])): ?>
              <td><?php echo htmlspecialchars($solicitud['nombre_cliente']); ?></td>
              <?php endif; ?>
              <?php if (isset($solicitud['empresa'])): ?>
              <td><?php echo htmlspecialchars($solicitud['empresa']); ?></td>
              <?php endif; ?>
              <td>
                  <?php 
                  if (isset($solicitud['nombre_encargado'])) {
                      echo htmlspecialchars($solicitud['nombre_encargado']);
                  } elseif (isset($solicitud['id_encargado'])) {
                      echo "ID: " . htmlspecialchars($solicitud['id_encargado']);
                  } else {
                      echo "No asignado";
                  }
                  ?>
              </td>
              <?php if (isset($solicitud['estado'])): ?>
              <td><?php echo htmlspecialchars($solicitud['estado']); ?></td>
              <?php endif; ?>
              <?php if (isset($solicitud['descripcion'])): ?>
              <td><?php echo htmlspecialchars($solicitud['descripcion']); ?></td>
              <?php endif; ?>
              <td>
                  <a href="editar_solicitud.php?id=<?php echo $solicitud['id']; ?>" class="btn btn-primary btn-sm">Editar</a>
                  <a href="ver_solicitud.php?id=<?php echo $solicitud['id']; ?>" class="btn btn-info btn-sm">Ver</a>
              </td>
          </tr>
          <?php endforeach; ?>
      </tbody>
  </table>
  <?php endif; ?>
  
  <a href="agregar_solicitud.php" class="btn btn-success">Agregar Nueva Solicitud</a>
</div>

<?php include 'layout_footer.php'; ?>

