<?php
session_start();
require 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['tipo'] != 'rh') {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $contrato_id = $_POST['contrato_id'];
    
    try {
        $pdo->beginTransaction();
        
        for ($i = 1; $i <= 6; $i++) {
            $requisito = isset($_POST["requisito_$i"]) ? 1 : 0;
            $stmt = $pdo->prepare("UPDATE contratos SET requisito_$i = ? WHERE id = ?");
            $stmt->execute([$requisito, $contrato_id]);
        }
        
        $pdo->commit();
        $_SESSION['mensaje'] = "Requisitos actualizados con éxito.";
    } catch (PDOException $e) {
        $pdo->rollBack();
        $_SESSION['error'] = "Error al actualizar los requisitos: " . $e->getMessage();
    }
}

// Redirigir de vuelta a la página desde donde se envió el formulario
$referer = $_SERVER['HTTP_REFERER'] ?? 'gestionar_contratos.php';
header("Location: $referer");
exit;

