<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['tipo'] != 'rh') {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['cambiar_estado'])) {
    $trabajador_id = $_POST['trabajador_id'];
    $nuevo_estado = $_POST['nuevo_estado'];
    
    try {
        $stmt = $pdo->prepare('UPDATE trabajadores SET estado = ? WHERE id = ?');
        $stmt->execute([$nuevo_estado, $trabajador_id]);
        $mensaje = "Estado del trabajador actualizado con éxito a: " . $nuevo_estado;
    } catch (PDOException $e) {
        $error = "Error al actualizar el estado del trabajador: " . $e->getMessage();
    }
}

$mensaje = '';
$error = '';
$trabajador = null;

if (isset($_GET['editar'])) {
    $id = $_GET['editar'];
    $stmt = $pdo->prepare('SELECT * FROM trabajadores WHERE id = ?');
    $stmt->execute([$id]);
    $trabajador = $stmt->fetch(PDO::FETCH_ASSOC);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'] ?? null;
    $nombre = $_POST['nombre'];
    $email = $_POST['email'] ?? null;
    $telefono = $_POST['telefono'] ?? null;
    $cedula = $_POST['cedula'] ?? null;
    $especialidad = $_POST['especialidad'] ?? null;
    $experiencia = !empty($_POST['experiencia']) ? intval($_POST['experiencia']) : null;
    $habilidades = $_POST['habilidades'] ?? null;

    try {
        if ($id) {
            // Actualizar trabajador existente
            $stmt = $pdo->prepare('UPDATE trabajadores SET nombre = ?, email = ?, telefono = ?, cedula = ?, especialidad = ?, experiencia = ?, habilidades = ? WHERE id = ?');
            $stmt->execute([$nombre, $email, $telefono, $cedula, $especialidad, $experiencia, $habilidades, $id]);
        } else {
            // Insertar nuevo trabajador
            $stmt = $pdo->prepare('INSERT INTO trabajadores (nombre, email, telefono, cedula, especialidad, experiencia, habilidades) VALUES (?, ?, ?, ?, ?, ?, ?)');
            $stmt->execute([$nombre, $email, $telefono, $cedula, $especialidad, $experiencia, $habilidades]);
        }
        $mensaje = $id ? 'Trabajador actualizado con éxito' : 'Trabajador agregado con éxito';
    } catch (PDOException $e) {
        $error = 'Error al ' . ($id ? 'actualizar' : 'agregar') . ' el trabajador: ' . $e->getMessage();
    }
}


$busqueda = isset($_GET['busqueda']) ? $_GET['busqueda'] : '';
$query = 'SELECT * FROM trabajadores WHERE nombre LIKE ? OR email LIKE ? OR cedula LIKE ? ORDER BY nombre';
$stmt = $pdo->prepare($query);
$busquedaParam = "%$busqueda%";
$stmt->execute([$busquedaParam, $busquedaParam, $busquedaParam]);
$trabajadores = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestionar Trabajadores - Sistema de Coordinación</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="layout">
        <aside class="sidebar">
            <h1 class="text-center mb-4">Sistema RH</h1>
            <nav>
                <ul class="nav-menu">
                    <li class="nav-item">
                        <a href="dashboard.php" class="nav-link">
                            <i class="fas fa-tachometer-alt"></i> Panel de Control
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="gestionar_solicitudes.php" class="nav-link">
                            <i class="fas fa-tasks"></i> Gestionar Solicitudes
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="agregar_solicitud.php" class="nav-link">
                            <i class="fas fa-plus-circle"></i> Agregar Solicitud
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="gestionar_clientes.php" class="nav-link">
                            <i class="fas fa-users"></i> Gestionar Clientes
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="gestionar_trabajadores.php" class="nav-link">
                            <i class="fas fa-hard-hat"></i> Gestionar Trabajadores
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="gestionar_contratos.php" class="nav-link">
                            <i class="fas fa-file-contract"></i> Gestionar Contratos
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="listar_trabajadores.php" class="nav-link">
                            <i class="fas fa-list"></i> Listado de Trabajadores
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="reportes_analisis.php" class="nav-link">
                            <i class="fas fa-chart-bar"></i> Reportes y Análisis
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="reporte_diario.php" class="nav-link">
                            <i class="fas fa-calendar-day"></i> Reporte Diario
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="logout.php" class="nav-link">
                            <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>
        <main class="main-content">
            <div class="container">
                <h2><?php echo $trabajador ? 'Editar Trabajador' : 'Agregar Nuevo Trabajador'; ?></h2>
                
                <?php if (isset($mensaje)): ?>
                    <div class="alert alert-success">
                        <?php echo htmlspecialchars($mensaje); ?>
                    </div>
                <?php endif; ?>
                <?php if (isset($error)): ?>
                    <div class="alert alert-error">
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>

                <div class="card mb-4">
                    <form method="POST" class="form-trabajador">
                        <?php if ($trabajador): ?>
                            <input type="hidden" name="id" value="<?php echo $trabajador['id']; ?>">
                        <?php endif; ?>
                        <div class="form-group">
                            <label for="nombre" class="form-label">Nombre del trabajador:</label>
                            <input type="text" id="nombre" name="nombre" class="form-input" value="<?php echo htmlspecialchars($trabajador['nombre'] ?? ''); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="email" class="form-label">Email:</label>
                            <input type="email" id="email" name="email" class="form-input" value="<?php echo htmlspecialchars($trabajador['email'] ?? ''); ?>">
                        </div>
                        <div class="form-group">
                            <label for="telefono" class="form-label">Teléfono:</label>
                            <input type="tel" id="telefono" name="telefono" class="form-input" value="<?php echo htmlspecialchars($trabajador['telefono'] ?? ''); ?>">
                        </div>
                        <div class="form-group">
                            <label for="cedula" class="form-label">Número de Cédula:</label>
                            <input type="text" id="cedula" name="cedula" class="form-input" value="<?php echo htmlspecialchars($trabajador['cedula'] ?? ''); ?>">
                        </div>
                        <div class="form-group">
                            <label for="especialidad" class="form-label">Especialidad:</label>
                            <input type="text" id="especialidad" name="especialidad" class="form-input" value="<?php echo htmlspecialchars($trabajador['especialidad'] ?? ''); ?>">
                        </div>
                        <div class="form-group">
                            <label for="experiencia" class="form-label">Años de experiencia:</label>
                            <input type="number" id="experiencia" name="experiencia" class="form-input" value="<?php echo htmlspecialchars($trabajador['experiencia'] ?? ''); ?>">
                        </div>
                        <div class="form-group">
                            <label for="habilidades" class="form-label">Habilidades:</label>
                            <textarea id="habilidades" name="habilidades" class="form-input"><?php echo htmlspecialchars($trabajador['habilidades'] ?? ''); ?></textarea>
                        </div>
                        <button type="submit" class="btn"><?php echo $trabajador ? 'Actualizar Trabajador' : 'Agregar Trabajador'; ?></button>
                    </form>
                </div>
                
                <h3>Buscar Trabajadores</h3>
                <form method="GET" class="form-busqueda mb-4">
                    <div class="form-group">
                        <input type="text" name="busqueda" class="form-input" placeholder="Buscar por nombre, email o cédula" value="<?php echo htmlspecialchars($busqueda); ?>">
                    </div>
                    <button type="submit" class="btn">Buscar</button>
                </form>

                <h3>Lista de Trabajadores</h3>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Nombre</th>
                                <th>Email</th>
                                <th>Teléfono</th>
                                <th>Cédula</th>
                                <th>Especialidad</th>
                                <th>Experiencia</th>
                                <th>Estado</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($trabajadores as $t): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($t['nombre']); ?></td>
                                    <td><?php echo htmlspecialchars($t['email']); ?></td>
                                    <td><?php echo htmlspecialchars($t['telefono']); ?></td>
                                    <td><?php echo htmlspecialchars($t['cedula']); ?></td>
                                    <td><?php echo htmlspecialchars($t['especialidad']); ?></td>
                                    <td><?php echo htmlspecialchars($t['experiencia']); ?> años</td>
                                    <td><?php echo htmlspecialchars($t['estado']); ?></td>
                                    <td>
                                        <a href="?editar=<?php echo $t['id']; ?>" class="btn btn-small">Editar</a>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="trabajador_id" value="<?php echo $t['id']; ?>">
                                            <input type="hidden" name="nuevo_estado" value="<?php echo $t['estado'] == 'habilitado' ? 'deshabilitado' : 'habilitado'; ?>">
                                            <button type="submit" name="cambiar_estado" class="btn btn-small <?php echo $t['estado'] == 'habilitado' ? 'btn-danger' : 'btn-success'; ?>">
                                                <?php echo $t['estado'] == 'habilitado' ? 'Deshabilitar' : 'Habilitar'; ?>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
























