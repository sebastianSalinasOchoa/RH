<?php
session_start();
require 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['tipo'] != 'rh') {
    header('Location: login.php');
    exit;
}

$mensaje = '';

// Obtener lista de clientes
$stmt = $pdo->query("SELECT id, nombre_empresa FROM clientes ORDER BY nombre_empresa");
$clientes = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $cliente_id = $_POST['cliente_id'];
    $descripcion = $_POST['descripcion'];
    $estado = $_POST['estado'];
    $personas_solicitadas = $_POST['personas_solicitadas'];
    $requisitos = $_POST['requisitos'];

    try {
        $pdo->beginTransaction();

        $stmt = $pdo->prepare("INSERT INTO solicitudes (cliente_id, descripcion, estado, fecha_creacion) VALUES (?, ?, ?, NOW())");
        $stmt->execute([$cliente_id, $descripcion, $estado]);
        $solicitud_id = $pdo->lastInsertId();

        $stmt = $pdo->prepare("INSERT INTO detalles_solicitud (solicitud_id, personas_solicitadas, requisitos) VALUES (?, ?, ?)");
        $stmt->execute([$solicitud_id, $personas_solicitadas, $requisitos]);

        $pdo->commit();
        $mensaje = "Solicitud agregada con éxito.";
    } catch (PDOException $e) {
        $pdo->rollBack();
        $mensaje = "Error al agregar la solicitud: " . $e->getMessage();
    }
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Solicitud - Sistema de Coordinación</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="layout">
        <aside class="sidebar">
            <h1 class="text-center mb-4">Sistema RH</h1>
            <nav>
                <ul class="nav-menu">
                    <li class="nav-item">
                        <a href="dashboard.php" class="nav-link">
                            <i class="fas fa-tachometer-alt"></i> Panel de Control
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="gestionar_solicitudes.php" class="nav-link">
                            <i class="fas fa-tasks"></i> Gestionar Solicitudes
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="agregar_solicitud.php" class="nav-link">
                            <i class="fas fa-plus-circle"></i> Agregar Solicitud
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="gestionar_clientes.php" class="nav-link">
                            <i class="fas fa-users"></i> Gestionar Clientes
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="gestionar_trabajadores.php" class="nav-link">
                            <i class="fas fa-hard-hat"></i> Gestionar Trabajadores
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="listar_trabajadores.php" class="nav-link">
                            <i class="fas fa-list"></i> Listado de Trabajadores
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="reportes_analisis.php" class="nav-link">
                            <i class="fas fa-chart-bar"></i> Reportes y Análisis
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="reporte_diario.php" class="nav-link">
                            <i class="fas fa-calendar-day"></i> Reporte Diario
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="logout.php" class="nav-link">
                            <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>
        <main class="main-content">
            <div class="container">
                <h2>Agregar Nueva Solicitud</h2>
                
                <?php if ($mensaje): ?>
                    <div class="alert <?php echo strpos($mensaje, 'Error') !== false ? 'alert-error' : 'alert-success'; ?>">
                        <?php echo htmlspecialchars($mensaje); ?>
                    </div>
                <?php endif; ?>

                <div class="card">
                    <form method="POST" class="form-solicitud">
                        <div class="form-group">
                            <label for="cliente_id" class="form-label">Cliente:</label>
                            <select id="cliente_id" name="cliente_id" class="form-input" required>
                                <option value="">Seleccione un cliente</option>
                                <?php foreach ($clientes as $cliente): ?>
                                    <option value="<?php echo $cliente['id']; ?>"><?php echo htmlspecialchars($cliente['nombre_empresa']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="descripcion" class="form-label">Descripción de la solicitud:</label>
                            <textarea id="descripcion" name="descripcion" class="form-input" required></textarea>
                        </div>
                        <div class="form-group">
                            <label for="personas_solicitadas" class="form-label">Número de personas solicitadas:</label>
                            <input type="number" id="personas_solicitadas" name="personas_solicitadas" class="form-input" required min="1">
                        </div>
                        <div class="form-group">
                            <label for="requisitos" class="form-label">Requisitos:</label>
                            <textarea id="requisitos" name="requisitos" class="form-input" required></textarea>
                        </div>
                        <div class="form-group">
                            <label for="estado" class="form-label">Estado inicial:</label>
                            <select id="estado" name="estado" class="form-input" required>
                                <option value="recibida">Recibida</option>
                                <option value="en_proceso">En Proceso</option>
                                <option value="ejecutada">Ejecutada</option>
                                <option value="finalizada">Finalizada</option>
                            </select>
                        </div>
                        <button type="submit" class="btn">Agregar Solicitud</button>
                    </form>
                </div>
            </div>
        </main>
    </div>
</body>
</html>








