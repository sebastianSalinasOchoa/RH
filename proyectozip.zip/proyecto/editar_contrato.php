<?php
session_start();
require 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['tipo'] != 'rh') {
    header('Location: index.php');
    exit;
}

$mensaje = '';
$error = '';
$contrato = null;

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM contratos WHERE id = ?");
    $stmt->execute([$id]);
    $contrato = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$contrato) {
        header('Location: gestionar_contratos.php');
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $cedula = $_POST['cedula'];
    $telefono = $_POST['telefono'];
    $puesto = $_POST['puesto'];
    $lugar_trabajo = $_POST['lugar_trabajo'];
    $fecha_inicio = $_POST['fecha_inicio'];
    $fecha_finalizacion = $_POST['fecha_finalizacion'];
    
    // Actualizar requisitos
    $requisito_1 = isset($_POST['requisito_1']) ? 1 : 0;
    $requisito_2 = isset($_POST['requisito_2']) ? 1 : 0;
    $requisito_3 = isset($_POST['requisito_3']) ? 1 : 0;
    $requisito_4 = isset($_POST['requisito_4']) ? 1 : 0;
    $requisito_5 = isset($_POST['requisito_5']) ? 1 : 0;
    $requisito_6 = isset($_POST['requisito_6']) ? 1 : 0;

    // Calcular estado
    $estado = (strtotime($fecha_finalizacion) >= strtotime(date('Y-m-d'))) ? "Vigente" : "Vencido";

    try {
        $pdo->beginTransaction();

        // Actualizar información básica
        $stmt = $pdo->prepare("UPDATE contratos SET 
            nombre_colaborador = ?, 
            cedula = ?, 
            telefono = ?, 
            puesto = ?, 
            lugar_trabajo = ?, 
            fecha_inicio = ?, 
            fecha_finalizacion = ?, 
            estado = ?,
            requisito_1 = ?,
            requisito_2 = ?,
            requisito_3 = ?,
            requisito_4 = ?,
            requisito_5 = ?,
            requisito_6 = ?
            WHERE id = ?");
        
        $stmt->execute([
            $nombre, $cedula, $telefono, $puesto, $lugar_trabajo, 
            $fecha_inicio, $fecha_finalizacion, $estado,
            $requisito_1, $requisito_2, $requisito_3, 
            $requisito_4, $requisito_5, $requisito_6,
            $id
        ]);

        // Manejar nuevo archivo si se subió uno
        if (isset($_FILES['archivo']) && $_FILES['archivo']['error'] == 0) {
            $archivo = $_FILES['archivo'];
            $nombre_archivo = uniqid() . '_' . basename($archivo['name']);
            $directorio_destino = 'archivos/contratos/';
            $ruta_archivo = $directorio_destino . $nombre_archivo;

            if (move_uploaded_file($archivo['tmp_name'], $ruta_archivo)) {
                // Actualizar la ruta del archivo en la base de datos
                $stmt = $pdo->prepare("UPDATE contratos SET pdf_url = ? WHERE id = ?");
                $stmt->execute([$ruta_archivo, $id]);
            }
        }

        $pdo->commit();
        $mensaje = "Contrato actualizado con éxito.";
        
        // Recargar los datos del contrato
        $stmt = $pdo->prepare("SELECT * FROM contratos WHERE id = ?");
        $stmt->execute([$id]);
        $contrato = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = "Error al actualizar el contrato: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Contrato - Sistema de Coordinación</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="layout">
        <aside class="sidebar">
            <!-- Mismo sidebar que en gestionar_contratos.php -->
        </aside>
        <main class="main-content">
            <div class="container">
                <h2>Editar Contrato</h2>
                
                <?php if ($mensaje): ?>
                    <div class="alert alert-success">
                        <?php echo htmlspecialchars($mensaje); ?>
                    </div>
                <?php endif; ?>
                <?php if ($error): ?>
                    <div class="alert alert-error">
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>

                <div class="card">
                    <form method="POST" enctype="multipart/form-data" class="form-contrato">
                        <input type="hidden" name="id" value="<?php echo $contrato['id']; ?>">
                        
                        <div class="form-group">
                            <label for="nombre">Nombre del Colaborador:</label>
                            <input type="text" id="nombre" name="nombre" value="<?php echo htmlspecialchars($contrato['nombre_colaborador']); ?>" required class="form-input">
                        </div>
                        
                        <div class="form-group">
                            <label for="cedula">Cédula:</label>
                            <input type="text" id="cedula" name="cedula" value="<?php echo htmlspecialchars($contrato['cedula']); ?>" required class="form-input">
                        </div>
                        
                        <div class="form-group">
                            <label for="telefono">Teléfono:</label>
                            <input type="tel" id="telefono" name="telefono" value="<?php echo htmlspecialchars($contrato['telefono']); ?>" required class="form-input">
                        </div>
                        
                        <div class="form-group">
                            <label for="puesto">Puesto:</label>
                            <input type="text" id="puesto" name="puesto" value="<?php echo htmlspecialchars($contrato['puesto']); ?>" required class="form-input">
                        </div>
                        
                        <div class="form-group">
                            <label for="lugar_trabajo">Lugar de Trabajo:</label>
                            <input type="text" id="lugar_trabajo" name="lugar_trabajo" value="<?php echo htmlspecialchars($contrato['lugar_trabajo']); ?>" required class="form-input">
                        </div>
                        
                        <div class="form-group">
                            <label for="fecha_inicio">Fecha de Inicio:</label>
                            <input type="date" id="fecha_inicio" name="fecha_inicio" value="<?php echo $contrato['fecha_inicio']; ?>" required class="form-input">
                        </div>
                        
                        <div class="form-group">
                            <label for="fecha_finalizacion">Fecha de Finalización:</label>
                            <input type="date" id="fecha_finalizacion" name="fecha_finalizacion" value="<?php echo $contrato['fecha_finalizacion']; ?>" required class="form-input">
                        </div>
                        
                        <div class="requisitos-container">
                            <h4>Requisitos:</h4>
                            <div class="checkbox-group">
                                <label>
                                    <input type="checkbox" name="requisito_1" <?php echo $contrato['requisito_1'] ? 'checked' : ''; ?>> 
                                    Requisito 1
                                </label>
                                <label>
                                    <input type="checkbox" name="requisito_2" <?php echo $contrato['requisito_2'] ? 'checked' : ''; ?>> 
                                    Requisito 2
                                </label>
                                <label>
                                    <input type="checkbox" name="requisito_3" <?php echo $contrato['requisito_3'] ? 'checked' : ''; ?>> 
                                    Requisito 3
                                </label>
                                <label>
                                    <input type="checkbox" name="requisito_4" <?php echo $contrato['requisito_4'] ? 'checked' : ''; ?>> 
                                    Requisito 4
                                </label>
                                <label>
                                    <input type="checkbox" name="requisito_5" <?php echo $contrato['requisito_5'] ? 'checked' : ''; ?>> 
                                    Requisito 5
                                </label>
                                <label>
                                    <input type="checkbox" name="requisito_6" <?php echo $contrato['requisito_6'] ? 'checked' : ''; ?>> 
                                    Requisito 6
                                </label>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="archivo">Nuevo Archivo del Contrato (opcional):</label>
                            <input type="file" id="archivo" name="archivo" accept=".pdf,.doc,.docx" class="form-input">
                            <?php if ($contrato['pdf_url']): ?>
                                <p class="archivo-actual">
                                    Archivo actual: 
                                    <a href="<?php echo htmlspecialchars($contrato['pdf_url']); ?>" target="_blank">
                                        Ver archivo actual
                                    </a>
                                </p>
                            <?php endif; ?>
                        </div>
                        
                        <div class="form-actions">
                            <button type="submit" class="btn">Guardar Cambios</button>
                            <a href="gestionar_contratos.php" class="btn btn-secondary">Cancelar</a>
                        </div>
                    </form>
                </div>
            </div>
        </main>
    </div>
</body>
</html>

