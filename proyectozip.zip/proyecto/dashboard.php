<?php
session_start();
require 'db_connect.php';
require 'layout_header.php';

// Verificar si el usuario está autenticado y es de tipo 'rh'
if (!isset($_SESSION['user_id']) || $_SESSION['tipo'] != 'rh') {
    header('Location: login.php');
    exit;
}

// Obtener estadísticas generales
$stmt = $pdo->query('SELECT COUNT(*) as total_solicitudes FROM solicitudes');
$total_solicitudes = $stmt->fetch(PDO::FETCH_ASSOC)['total_solicitudes'];

$stmt = $pdo->query('SELECT COUNT(*) as solicitudes_pendientes FROM solicitudes WHERE estado IN ("recibida", "en_proceso")');
$solicitudes_pendientes = $stmt->fetch(PDO::FETCH_ASSOC)['solicitudes_pendientes'];

$stmt = $pdo->query('SELECT COUNT(*) as total_trabajadores FROM trabajadores');
$total_trabajadores = $stmt->fetch(PDO::FETCH_ASSOC)['total_trabajadores'];

$stmt = $pdo->query('SELECT COUNT(*) as total_clientes FROM clientes');
$total_clientes = $stmt->fetch(PDO::FETCH_ASSOC)['total_clientes'];

// Render header
renderHeader('Panel de Control');
?>
            <main class="main-content">
                <header class="main-header">
                    <div class="logo-container">
                        <img src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-7iWXMQo4nxg0caC9kuKxjIvUAoVJW4.png" alt="Servicios Expenic" class="main-logo">
                    </div>
                    <div class="header-content">
                        <h1>Sistema de Gestión de Recursos Humanos</h1>
                        <p>Soluciones integrales en outsourcing</p>
                    </div>
                </header>

                <div class="container">
                    <div class="dashboard-stats">
                        <div class="stat-card">
                            <h3>Total Solicitudes</h3>
                            <p><?php echo $total_solicitudes; ?></p>
                        </div>
                        <div class="stat-card">
                            <h3>Solicitudes Pendientes</h3>
                            <p><?php echo $solicitudes_pendientes; ?></p>
                        </div>
                        <div class="stat-card">
                            <h3>Total Trabajadores</h3>
                            <p><?php echo $total_trabajadores; ?></p>
                        </div>
                        <div class="stat-card">
                            <h3>Total Clientes</h3>
                            <p><?php echo $total_clientes; ?></p>
                        </div>
                    </div>

                    <div class="card">
                        <h2>Bienvenido al Sistema de Gestión</h2>
                        <p>Gestione eficientemente sus recursos humanos y solicitudes de servicio con nuestra plataforma especializada.</p>
                    </div>

                    <div class="chart-container">
                        <canvas id="solicitudesChart"></canvas>
                    </div>
                </div>
            </main>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <script>
            // Configuración del gráfico con los colores de la empresa
            const ctx = document.getElementById('solicitudesChart').getContext('2d');
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun'],
                    datasets: [{
                        label: 'Solicitudes por Mes',
                        data: [12, 19, 3, 5, 2, 3],
                        backgroundColor: '#1E3C72',
                        borderColor: '#3282B8',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        </script>
    </body>
    </html>


