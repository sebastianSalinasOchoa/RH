<?php
session_start();
require 'db_connect.php';
require 'vendor/autoload.php';

use FPDF\FPDF;

if (!isset($_SESSION['user_id']) || $_SESSION['tipo'] != 'rh') {
    header('Location: index.php');
    exit;
}

// Obtener la fecha actual
$fecha_actual = date('Y-m-d');

// Consulta para obtener los trabajadores asignados hoy, los clientes y el conteo
$query = "
    SELECT 
        c.nombre_empresa AS cliente,
        COUNT(DISTINCT a.trabajador_id) AS num_trabajadores,
        GROUP_CONCAT(DISTINCT t.nombre SEPARATOR ', ') AS trabajadores
    FROM 
        asignaciones a
    JOIN 
        solicitudes s ON a.solicitud_id = s.id
    JOIN 
        clientes c ON s.cliente_id = c.id
    JOIN 
        trabajadores t ON a.trabajador_id = t.id
    WHERE 
        a.fecha_asignacion = :fecha_actual
    GROUP BY 
        c.id
    ORDER BY 
        c.nombre_empresa
";

$stmt = $pdo->prepare($query);
$stmt->execute(['fecha_actual' => $fecha_actual]);
$asignaciones = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Obtener el total de trabajadores asignados hoy
$query_total = "
    SELECT COUNT(DISTINCT trabajador_id) AS total_trabajadores
    FROM asignaciones
    WHERE fecha_asignacion = :fecha_actual
";

$stmt_total = $pdo->prepare($query_total);
$stmt_total->execute(['fecha_actual' => $fecha_actual]);
$total_trabajadores = $stmt_total->fetch(PDO::FETCH_ASSOC)['total_trabajadores'];

// Crear el PDF
$pdf = new FPDF();
$pdf->AddPage();

// Configurar la fuente
$pdf->SetFont('Arial', 'B', 16);

// Título
$pdf->Cell(0, 10, 'Reporte Diario - ' . date('d/m/Y', strtotime($fecha_actual)), 0, 1, 'C');
$pdf->Ln(10);

// Total de trabajadores asignados
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(0, 10, 'Total Trabajadores Asignados Hoy: ' . $total_trabajadores, 0, 1);
$pdf->Ln(10);

// Tabla de asignaciones
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(60, 10, 'Cliente', 1);
$pdf->Cell(40, 10, 'Num. Trabajadores', 1);
$pdf->Cell(90, 10, 'Trabajadores Asignados', 1);
$pdf->Ln();

$pdf->SetFont('Arial', '', 10);
foreach ($asignaciones as $asignacion) {
    $pdf->Cell(60, 10, utf8_decode($asignacion['cliente']), 1);
    $pdf->Cell(40, 10, $asignacion['num_trabajadores'], 1);
    $pdf->Cell(90, 10, utf8_decode($asignacion['trabajadores']), 1);
    $pdf->Ln();
}

// Generar el PDF
$pdf->Output('Reporte_Diario_' . date('Y-m-d') . '.pdf', 'I');

