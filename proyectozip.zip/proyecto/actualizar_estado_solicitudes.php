<?php
session_start();
require 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['tipo'] != 'cliente') {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'No autorizado']);
    exit;
}

$user_id = $_SESSION['user_id'];

$stmt = $pdo->prepare('SELECT s.id, s.estado, s.descripcion, s.fecha_creacion FROM solicitudes s WHERE s.cliente_id = ? AND s.estado != "finalizada"');
$stmt->execute([$user_id]);
$solicitudes = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($solicitudes as &$solicitud) {
    $stmt = $pdo->prepare('SELECT t.nombre FROM trabajadores t JOIN asignaciones a ON t.id = a.trabajador_id WHERE a.solicitud_id = ?');
    $stmt->execute([$solicitud['id']]);
    $solicitud['trabajadores'] = $stmt->fetchAll(PDO::FETCH_COLUMN);
}

header('Content-Type: application/json');
echo json_encode($solicitudes);

