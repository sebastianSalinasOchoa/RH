<?php
session_start();
require 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$tipo_usuario = $_SESSION['tipo'];

// Obtener mensajes recibidos
$stmt = $pdo->prepare("SELECT m.*, u.username as remitente_nombre 
                       FROM mensajes m 
                       JOIN usuarios u ON m.remitente_id = u.id 
                       WHERE m.destinatario_id = ? 
                       ORDER BY m.fecha_envio DESC");
$stmt->execute([$user_id]);
$mensajes_recibidos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Obtener usuarios para enviar mensajes
if ($tipo_usuario == 'rh') {
    $stmt = $pdo->query("SELECT id, username, tipo FROM usuarios WHERE tipo != 'rh'");
} else {
    $stmt = $pdo->query("SELECT id, username, tipo FROM usuarios WHERE tipo = 'rh'");
}
$usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Enviar mensaje
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['enviar_mensaje'])) {
    $destinatario_id = $_POST['destinatario_id'];
    $asunto = $_POST['asunto'];
    $contenido = $_POST['contenido'];

    $stmt = $pdo->prepare("INSERT INTO mensajes (remitente_id, destinatario_id, asunto, contenido) VALUES (?, ?, ?, ?)");
    $stmt->execute([$user_id, $destinatario_id, $asunto, $contenido]);

    $mensaje_exito = "Mensaje enviado con éxito.";
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Mensajería</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Sistema de Mensajería</h1>

        <?php if (isset($mensaje_exito)): ?>
            <p class="mensaje-exito"><?php echo $mensaje_exito; ?></p>
        <?php endif; ?>

        <h2>Enviar Nuevo Mensaje</h2>
        <form method="POST" class="form-mensaje">
            <div>
                <label for="destinatario_id">Destinatario:</label>
                <select id="destinatario_id" name="destinatario_id" required>
                    <?php foreach ($usuarios as $usuario): ?>
                        <option value="<?php echo $usuario['id']; ?>">
                            <?php echo htmlspecialchars($usuario['username']) . ' (' . $usuario['tipo'] . ')'; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label for="asunto">Asunto:</label>
                <input type="text" id="asunto" name="asunto" required>
            </div>
            <div>
                <label for="contenido">Mensaje:</label>
                <textarea id="contenido" name="contenido" required></textarea>
            </div>
            <button type="submit" name="enviar_mensaje">Enviar Mensaje</button>
        </form>

        <h2>Mensajes Recibidos</h2>
        <?php if (empty($mensajes_recibidos)): ?>
            <p>No tienes mensajes recibidos.</p>
        <?php else: ?>
            <table class="tabla-mensajes">
                <tr>
                    <th>Remitente</th>
                    <th>Asunto</th>
                    <th>Fecha</th>
                    <th>Acciones</th>
                </tr>
                <?php foreach ($mensajes_recibidos as $mensaje): ?>
                    <tr class="<?php echo $mensaje['leido'] ? '' : 'mensaje-no-leido'; ?>">
                        <td><?php echo htmlspecialchars($mensaje['remitente_nombre']); ?></td>
                        <td><?php echo htmlspecialchars($mensaje['asunto']); ?></td>
                        <td><?php echo $mensaje['fecha_envio']; ?></td>
                        <td>
                            <a href="ver_mensaje.php?id=<?php echo $mensaje['id']; ?>" class="button">Ver</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>

        <a href="index.php" class="button">Volver al inicio</a>
    </div>
</body>
</html>

