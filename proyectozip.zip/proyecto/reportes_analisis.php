<?php
session_start();
require 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['tipo'] != 'rh') {
    header('Location: index.php');
    exit;
}

// Obtener estadísticas generales
$stmt = $pdo->query('SELECT COUNT(*) as total_solicitudes FROM solicitudes');
$total_solicitudes = $stmt->fetch(PDO::FETCH_ASSOC)['total_solicitudes'];

$stmt = $pdo->query('SELECT COUNT(*) as solicitudes_completadas FROM solicitudes WHERE estado = "finalizada"');
$solicitudes_completadas = $stmt->fetch(PDO::FETCH_ASSOC)['solicitudes_completadas'];

$stmt = $pdo->query('SELECT COUNT(*) as total_trabajadores FROM trabajadores');
$total_trabajadores = $stmt->fetch(PDO::FETCH_ASSOC)['total_trabajadores'];

// Obtener solicitudes por estado
$stmt = $pdo->query('SELECT estado, COUNT(*) as cantidad FROM solicitudes GROUP BY estado');
$solicitudes_por_estado = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Obtener top 5 trabajadores más asignados
$stmt = $pdo->query('SELECT t.nombre, COUNT(a.id) as asignaciones 
                   FROM trabajadores t 
                   JOIN asignaciones a ON t.id = a.trabajador_id 
                   GROUP BY t.id 
                   ORDER BY asignaciones DESC 
                   LIMIT 5');
$top_trabajadores = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Obtener solicitudes por mes
$stmt = $pdo->query('SELECT DATE_FORMAT(fecha_creacion, "%Y-%m") as mes, COUNT(*) as cantidad 
                   FROM solicitudes 
                   GROUP BY mes 
                   ORDER BY mes DESC 
                   LIMIT 12');
$solicitudes_por_mes = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reportes y Análisis - Sistema de Coordinación</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="layout">
        <aside class="sidebar">
            <h1 class="text-center mb-4">Sistema RH</h1>
            <nav>
                <ul class="nav-menu">
                    <li class="nav-item">
                        <a href="dashboard.php" class="nav-link">
                            <i class="fas fa-tachometer-alt"></i> Panel de Control
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="gestionar_solicitudes.php" class="nav-link">
                            <i class="fas fa-tasks"></i> Gestionar Solicitudes
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="agregar_solicitud.php" class="nav-link">
                            <i class="fas fa-plus-circle"></i> Agregar Solicitud
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="gestionar_clientes.php" class="nav-link">
                            <i class="fas fa-users"></i> Gestionar Clientes
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="gestionar_trabajadores.php" class="nav-link">
                            <i class="fas fa-hard-hat"></i> Gestionar Trabajadores
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="gestionar_contratos.php" class="nav-link">
                            <i class="fas fa-file-contract"></i> Gestionar Contratos
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="listar_trabajadores.php" class="nav-link">
                            <i class="fas fa-list"></i> Listado de Trabajadores
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="reportes_analisis.php" class="nav-link">
                            <i class="fas fa-chart-bar"></i> Reportes y Análisis
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="reporte_diario.php" class="nav-link">
                            <i class="fas fa-calendar-day"></i> Reporte Diario
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="logout.php" class="nav-link">
                            <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>
        <main class="main-content">
            <div class="container">
                <h2>Reportes y Análisis</h2>
                
                <div class="dashboard-stats">
                    <div class="stat-card">
                        <h3>Total Solicitudes</h3>
                        <p><?php echo $total_solicitudes; ?></p>
                    </div>
                    <div class="stat-card">
                        <h3>Solicitudes Completadas</h3>
                        <p><?php echo $solicitudes_completadas; ?></p>
                    </div>
                    <div class="stat-card">
                        <h3>Tasa de Finalización</h3>
                        <p><?php echo number_format(($solicitudes_completadas / $total_solicitudes) * 100, 2); ?>%</p>
                    </div>
                    <div class="stat-card">
                        <h3>Total Trabajadores</h3>
                        <p><?php echo $total_trabajadores; ?></p>
                    </div>
                </div>

                <div class="dashboard-charts">
                    <div class="chart-container">
                        <h3>Solicitudes por Estado</h3>
                        <canvas id="solicitudesEstadoChart"></canvas>
                    </div>
                    <div class="chart-container">
                        <h3>Solicitudes por Mes</h3>
                        <canvas id="solicitudesMesChart"></canvas>
                    </div>
                </div>

                <h3>Top 5 Trabajadores Más Asignados</h3>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Nombre</th>
                                <th>Asignaciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($top_trabajadores as $trabajador): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($trabajador['nombre']); ?></td>
                                    <td><?php echo $trabajador['asignaciones']; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <script>
    // Gráfico de solicitudes por estado
    var ctxEstado = document.getElementById('solicitudesEstadoChart').getContext('2d');
    var solicitudesEstadoChart = new Chart(ctxEstado, {
        type: 'pie',
        data: {
            labels: <?php echo json_encode(array_column($solicitudes_por_estado, 'estado')); ?>,
            datasets: [{
                data: <?php echo json_encode(array_column($solicitudes_por_estado, 'cantidad')); ?>,
                backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0']
            }]
        },
        options: {
            responsive: true,
            title: {
                display: true,
                text: 'Solicitudes por Estado'
            }
        }
    });

    // Gráfico de solicitudes por mes
    var ctxMes = document.getElementById('solicitudesMesChart').getContext('2d');
    var solicitudesMesChart = new Chart(ctxMes, {
        type: 'line',
        data: {
            labels: <?php echo json_encode(array_column($solicitudes_por_mes, 'mes')); ?>,
            datasets: [{
                label: 'Número de Solicitudes',
                data: <?php echo json_encode(array_column($solicitudes_por_mes, 'cantidad')); ?>,
                borderColor: '#36A2EB',
                fill: false
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            },
            title: {
                display: true,
                text: 'Solicitudes por Mes'
            }
        }
    });
    </script>
</body>
</html>




