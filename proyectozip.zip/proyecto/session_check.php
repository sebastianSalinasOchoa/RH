<?php
session_start();

// Función para verificar si el usuario está autenticado
function isAuthenticated() {
    return isset($_SESSION['user_id']);
}

// Función para verificar si el usuario tiene el rol requerido
function hasRole($requiredRole) {
    return isset($_SESSION['tipo']) && $_SESSION['tipo'] == $requiredRole;
}

// Función para redirigir si no está autenticado
function redirectIfNotAuthenticated() {
    if (!isAuthenticated()) {
        header('Location: login.php');
        exit;
    }
}

// Función para redirigir si no tiene el rol requerido
function redirectIfNotAuthorized($requiredRoles) {
    if (!is_array($requiredRoles)) {
        $requiredRoles = [$requiredRoles];
    }
    if (!in_array($_SESSION['tipo'], $requiredRoles)) {
        header('Location: unauthorized.php');
        exit;
    }
}

// Verificar la autenticación en cada página
redirectIfNotAuthenticated();

