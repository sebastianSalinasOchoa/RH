<?php
session_start();
require 'db_connect.php';
require 'layout_header.php';

// Verificar si el usuario está autenticado y es admin
if (!isset($_SESSION['user_id']) || $_SESSION['tipo'] != 'admin') {
    header('Location: login.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $tipo = $_POST['tipo'] ?? '';

    if (empty($username) || empty($email) || empty($password) || empty($tipo)) {
        $error = "Todos los campos son obligatorios.";
    } else {
        $stmt = $pdo->prepare("INSERT INTO usuarios (username, email, password, tipo, activo) VALUES (?, ?, ?, ?, 1)");
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        if ($stmt->execute([$username, $email, $hashed_password, $tipo])) {
            $success = "Usuario creado exitosamente.";
        } else {
            $error = "Error al crear el usuario.";
        }
    }
}

// Render header
renderHeader('Crear Usuario');
?>

<main class="main-content">
    <div class="container">
        <h1>Crear Nuevo Usuario</h1>
        
        <?php if ($error): ?>
            <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="success-message"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        
        <form method="POST" action="crear_usuario.php" class="form-contrato">
            <div class="form-group">
                <label for="username">Nombre de Usuario:</label>
                <input type="text" id="username" name="username" required class="form-input">
            </div>
            
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required class="form-input">
            </div>
            
            <div class="form-group">
                <label for="password">Contraseña:</label>
                <input type="password" id="password" name="password" required class="form-input">
            </div>
            
            <div class="form-group">
                <label for="tipo">Tipo de Usuario:</label>
                <select id="tipo" name="tipo" required class="form-input">
                    <option value="admin">Admin</option>
                    <option value="rh">RH</option>
                    <option value="usuario">Usuario Regular</option>
                </select>
            </div>
            
            <button type="submit" class="btn btn-primary">Crear Usuario</button>
        </form>
        
        <a href="admin_usuarios.php" class="btn btn-secondary mt-3">Volver a la lista de usuarios</a>
    </div>
</main>

<?php include 'layout_footer.php'; ?>

