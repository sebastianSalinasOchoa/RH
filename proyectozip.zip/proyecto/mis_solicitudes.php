<?php
session_start();
require 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['tipo'] != 'cliente') {
    header('Location: index.php');
    exit;
}

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $solicitud_id = $_POST['solicitud_id'];
    $estrellas = $_POST['estrellas'];
    $comentario = $_POST['comentario'];

    $pdo->beginTransaction();

    try {
        $stmt = $pdo->prepare('UPDATE solicitudes SET estado = "finalizada" WHERE id = ? AND cliente_id = ?');
        $stmt->execute([$solicitud_id, $user_id]);

        $stmt = $pdo->prepare('INSERT INTO valoraciones (solicitud_id, estrellas, comentario) VALUES (?, ?, ?)');
        $stmt->execute([$solicitud_id, $estrellas, $comentario]);

        $pdo->commit();
        $mensaje = 'Solicitud finalizada y valorada con éxito';
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = 'Error al finalizar la solicitud: ' . $e->getMessage();
    }
}

$stmt = $pdo->prepare('SELECT * FROM solicitudes WHERE cliente_id = ? ORDER BY fecha_creacion DESC');
$stmt->execute([$user_id]);
$solicitudes = $stmt->fetchAll();

function obtenerTrabajadoresAsignados($pdo, $solicitud_id) {
    $stmt = $pdo->prepare('SELECT t.nombre FROM trabajadores t JOIN asignaciones a ON t.id = a.trabajador_id WHERE a.solicitud_id = ?');
    $stmt->execute([$solicitud_id]);
    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Solicitudes</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        function actualizarEstadoSolicitudes() {
            $.ajax({
                url: 'actualizar_estado_solicitudes.php',
                method: 'GET',
                dataType: 'json',
                success: function(response) {
                    response.forEach(function(solicitud) {
                        var $solicitudDiv = $('#solicitud-' + solicitud.id);
                        $solicitudDiv.find('.estado').text(solicitud.estado);
                        $solicitudDiv.find('.trabajadores-asignados').html(solicitud.trabajadores.join(', '));
                        
                        if (solicitud.estado === 'ejecutada') {
                            $solicitudDiv.find('.form-valoracion').show();
                        } else {
                            $solicitudDiv.find('.form-valoracion').hide();
                        }
                        
                        // Actualizar otros campos si es necesario
                        $solicitudDiv.find('.descripcion').text(solicitud.descripcion);
                        $solicitudDiv.find('.fecha-creacion').text(solicitud.fecha_creacion);
                    });
                },
                error: function(xhr, status, error) {
                    console.error("Error al actualizar solicitudes:", error);
                }
            });
        }

        $(document).ready(function() {
            actualizarEstadoSolicitudes(); // Actualizar inmediatamente al cargar la página
            setInterval(actualizarEstadoSolicitudes, 5000); // Actualizar cada 5 segundos
        });
    </script>
</head>
<body>
    <div class="container">
        <h1>Mis Solicitudes</h1>
        <?php if (isset($mensaje)): ?>
            <p class="mensaje"><?php echo $mensaje; ?></p>
        <?php endif; ?>
        <?php if (isset($error)): ?>
            <p class="error"><?php echo $error; ?></p>
        <?php endif; ?>
        <?php foreach ($solicitudes as $solicitud): ?>
            <div id="solicitud-<?php echo $solicitud['id']; ?>" class="solicitud">
                <h2>Solicitud #<?php echo $solicitud['id']; ?></h2>
                <p><strong>Descripción:</strong> <span class="descripcion"><?php echo htmlspecialchars($solicitud['descripcion']); ?></span></p>
                <p><strong>Estado:</strong> <span class="estado"><?php echo htmlspecialchars($solicitud['estado']); ?></span></p>
                <p><strong>Fecha de creación:</strong> <span class="fecha-creacion"><?php echo $solicitud['fecha_creacion']; ?></span></p>
                
                <p><strong>Trabajadores asignados:</strong> <span class="trabajadores-asignados"><?php echo implode(', ', obtenerTrabajadoresAsignados($pdo, $solicitud['id'])); ?></span></p>
                
                <form id="form-valoracion-<?php echo $solicitud['id']; ?>" class="form-valoracion" method="POST" style="display: <?php echo $solicitud['estado'] == 'ejecutada' ? 'block' : 'none'; ?>">
                    <input type="hidden" name="solicitud_id" value="<?php echo $solicitud['id']; ?>">
                    <div>
                        <label for="estrellas">Valoración (0-5 estrellas):</label>
                        <input type="number" id="estrellas" name="estrellas" min="0" max="5" required>
                    </div>
                    <div>
                        <label for="comentario">Comentario:</label>
                        <textarea id="comentario" name="comentario" required></textarea>
                    </div>
                    <button type="submit">Finalizar y Valorar</button>
                </form>
            </div>
        <?php endforeach; ?>
        <a href="index.php">Volver al inicio</a>
    </div>
</body>
</html>

