<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $nombre_empresa = $_POST['nombre_empresa'];
                $contacto = $_POST['contacto'];
                $requisitos_personal = $_POST['requisitos_personal'];
                $stmt = $conn->prepare("INSERT INTO clientes (nombre_empresa, contacto, requisitos_personal) VALUES (?, ?, ?)");
                $stmt->bind_param("sss", $nombre_empresa, $contacto, $requisitos_personal);
                $stmt->execute();
                break;
            case 'edit':
                $id = $_POST['id'];
                $nombre_empresa = $_POST['nombre_empresa'];
                $contacto = $_POST['contacto'];
                $requisitos_personal = $_POST['requisitos_personal'];
                $stmt = $conn->prepare("UPDATE clientes SET nombre_empresa = ?, contacto = ?, requisitos_personal = ? WHERE id = ?");
                $stmt->bind_param("sssi", $nombre_empresa, $contacto, $requisitos_personal, $id);
                $stmt->execute();
                break;
            case 'delete':
                $id = $_POST['id'];
                $stmt = $conn->prepare("DELETE FROM clientes WHERE id = ?");
                $stmt->bind_param("i", $id);
                $stmt->execute();
                break;
        }
    }
}

$search = isset($_GET['search']) ? $_GET['search'] : '';
$query = "SELECT * FROM clientes WHERE nombre_empresa LIKE ? OR contacto LIKE ?";
$search_param = "%$search%";
$stmt = $conn->prepare($query);
$stmt->bind_param("ss", $search_param, $search_param);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Clientes</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Gestión de Clientes</h1>
    <form method="get" class="search-form">
        <input type="text" name="search" placeholder="Buscar clientes" value="<?php echo htmlspecialchars($search); ?>">
        <input type="submit" value="Buscar">
    </form>
    <form method="post" id="clientForm">
        <input type="hidden" name="action" value="add">
        <input type="hidden" name="id" id="editId">
        <input type="text" name="nombre_empresa" placeholder="Nombre de la empresa" required>
        <input type="text" name="contacto" placeholder="Contacto" required>
        <textarea name="requisitos_personal" placeholder="Requisitos de personal"></textarea>
        <input type="submit" value="Agregar Cliente" id="submitBtn">
    </form>
    <table>
        <tr>
            <th>Nombre de la Empresa</th>
            <th>Contacto</th>
            <th>Requisitos de Personal</th>
            <th>Acciones</th>
        </tr>
        <?php while($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?php echo htmlspecialchars($row['nombre_empresa']); ?></td>
            <td><?php echo htmlspecialchars($row['contacto']); ?></td>
            <td><?php echo htmlspecialchars($row['requisitos_personal']); ?></td>
            <td>
                <button onclick="editClient(<?php echo $row['id']; ?>, '<?php echo addslashes($row['nombre_empresa']); ?>', '<?php echo addslashes($row['contacto']); ?>', '<?php echo addslashes($row['requisitos_personal']); ?>')">Editar</button>
                <form method="post" style="display:inline;">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                    <input type="submit" value="Eliminar" onclick="return confirm('¿Estás seguro de que quieres eliminar este cliente?');">
                </form>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
    <a href="index.php">Volver al Panel de Control</a>
    <script>
    function editClient(id, nombre_empresa, contacto, requisitos_personal) {
        document.getElementById('editId').value = id;
        document.getElementsByName('nombre_empresa')[0].value = nombre_empresa;
        document.getElementsByName('contacto')[0].value = contacto;
        document.getElementsByName('requisitos_personal')[0].value = requisitos_personal;
        document.getElementsByName('action')[0].value = 'edit';
        document.getElementById('submitBtn').value = 'Actualizar Cliente';
    }
    </script>
</body>
</html>