<?php
session_start();
require 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['tipo'] != 'cliente') {
    header('Location: index.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Obtener la información del cliente
$stmt = $pdo->prepare('SELECT empresa, telefono, email FROM usuarios WHERE id = ?');
$stmt->execute([$user_id]);
$cliente_info = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $descripcion = $_POST['descripcion'];
    $stmt = $pdo->prepare('INSERT INTO solicitudes (cliente_id, descripcion) VALUES (?, ?)');
    $stmt->execute([$user_id, $descripcion]);
    $mensaje = 'Solicitud creada con éxito';
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Solicitar Personal</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Solicitar Personal</h1>
        <?php if (isset($mensaje)): ?>
            <p class="mensaje"><?php echo $mensaje; ?></p>
        <?php endif; ?>
        <form method="POST">
            <div>
                <label for="empresa">Empresa:</label>
                <input type="text" id="empresa" name="empresa" value="<?php echo htmlspecialchars($cliente_info['empresa']); ?>" readonly>
            </div>
            <div>
                <label for="telefono">Teléfono:</label>
                <input type="tel" id="telefono" name="telefono" value="<?php echo htmlspecialchars($cliente_info['telefono']); ?>" readonly>
            </div>
            <div>
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($cliente_info['email']); ?>" readonly>
            </div>
            <div>
                <label for="descripcion">Descripción de la solicitud:</label>
                <textarea id="descripcion" name="descripcion" required></textarea>
            </div>
            <button type="submit">Enviar Solicitud</button>
        </form>
        <a href="index.php">Volver al inicio</a>
    </div>
</body>
</html>