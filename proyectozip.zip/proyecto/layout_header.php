<?php
function renderHeader($title) {
  if (session_status() == PHP_SESSION_NONE) {
      session_start();
  }
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo $title; ?> - Sistema de Gestión de RRHH</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="layout">
      <aside class="sidebar">
          <h2 class="sidebar-title">Sistema de Gestión</h2>
          <nav>
              <ul class="nav-menu">
                  <li class="nav-item">
                      <a href="dashboard.php" class="nav-link">
                          <i class="fas fa-tachometer-alt"></i> Panel de Control
                      </a>
                  </li>
                  <?php if ($_SESSION['tipo'] == 'rh' || $_SESSION['tipo'] == 'admin'): ?>
                  <li class="nav-item">
                      <a href="gestionar_solicitudes.php" class="nav-link">
                          <i class="fas fa-tasks"></i> Gestionar Solicitudes
                      </a>
                  </li>
                  <li class="nav-item">
                      <a href="agregar_solicitud.php" class="nav-link">
                          <i class="fas fa-plus"></i> Agregar Solicitud
                      </a>
                  </li>
                  <li class="nav-item">
                      <a href="gestionar_clientes.php" class="nav-link">
                          <i class="fas fa-user-tie"></i> Gestionar Clientes
                      </a>
                  </li>
                  <li class="nav-item">
                      <a href="gestionar_trabajadores.php" class="nav-link">
                          <i class="fas fa-users"></i> Gestionar Trabajadores
                      </a>
                  </li>
                  <li class="nav-item">
                      <a href="gestionar_contratos.php" class="nav-link">
                          <i class="fas fa-file-contract"></i> Gestionar Contratos
                      </a>
                  </li>
                  <li class="nav-item">
                      <a href="listar_trabajadores.php" class="nav-link">
                          <i class="fas fa-list"></i> Listado de Trabajadores
                      </a>
                  </li>
                  <li class="nav-item">
                      <a href="reportes_analisis.php" class="nav-link">
                          <i class="fas fa-chart-bar"></i> Reportes y Análisis
                      </a>
                  </li>
                  <li class="nav-item">
                      <a href="reporte_diario.php" class="nav-link">
                          <i class="fas fa-calendar-day"></i> Reporte Diario
                      </a>
                  </li>
                  <?php endif; ?>
                  <li class="nav-item">
                      <a href="logout.php" class="nav-link">
                          <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
                      </a>
                  </li>
              </ul>
          </nav>
      </aside>
      <main class="main-content">
          <header class="main-header">
              <div class="logo-container">
                  <img src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-7iWXMQo4nxg0caC9kuKxjIvUAoVJW4.png" alt="Servicios Expenic" class="main-logo">
              </div>
              <div class="header-content">
                  <h1><?php echo $title; ?></h1>
                  <p>Sistema de Gestión de Recursos Humanos</p>
              </div>
          </header>
          <div class="container">
<?php
}
?>





