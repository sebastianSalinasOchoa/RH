<?php
session_start();
require 'db_connect.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        $error = "Por favor, ingrese tanto el nombre de usuario como la contraseña.";
    } else {
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['tipo'] = $user['tipo'];

            // Redirigir basado en el tipo de usuario
            if ($user['tipo'] == 'rh') {
                header("Location: dashboard.php");
            } else {
                header("Location: dashboard_usuario.php");
            }
            exit();
        } else {
            $error = "Nombre de usuario o contraseña incorrectos.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión - Servicios Expenic</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body class="login-page">
    <div class="auth-container">
        <div class="auth-logo">
            <img src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-7iWXMQo4nxg0caC9kuKxjIvUAoVJW4.png" alt="Servicios Expenic Logo" class="logo">
        </div>
        <h2>Iniciar Sesión</h2>
        <?php if ($error): ?>
            <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <form class="auth-form" method="POST" action="login.php">
            <div class="form-group">
                <label for="username" class="form-label">
                    <i class="fas fa-user"></i> Usuario:
                </label>
                <input type="text" id="username" name="username" required class="form-input">
            </div>
            <div class="form-group">
                <label for="password" class="form-label">
                    <i class="fas fa-lock"></i> Contraseña:
                </label>
                <input type="password" id="password" name="password" required class="form-input">
            </div>
            <button type="submit" class="btn btn-primary">Iniciar Sesión</button>
        </form>
        <div class="auth-links">
            <a href="register.php">¿No tienes una cuenta? Regístrate</a>
        </div>
    </div>
</body>
</html>

