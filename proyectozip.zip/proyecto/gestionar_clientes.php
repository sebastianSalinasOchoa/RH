<?php
require_once 'session_start.php';
require_once 'layout_header.php';

// Verificar autenticación
redirectIfNotAuthenticated();

// Verificar autorización (asumiendo que solo 'admin' y 'rh' pueden acceder)
if (!hasRole('admin') && !hasRole('rh')) {
    redirectIfNotAuthorized('admin'); // Redirige a página de no autorizado
}

// Obtener lista de clientes
$stmt = $pdo->query("SELECT * FROM clientes ORDER BY nombre");
$clientes = $stmt->fetchAll();

renderHeader('Gestionar Clientes');
?>

<div class="container">
    <h2>Gestionar Clientes</h2>
    
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Empresa</th>
                <th>Email</th>
                <th>Teléfono</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($clientes as $cliente): ?>
            <tr>
                <td><?php echo htmlspecialchars($cliente['id']); ?></td>
                <td><?php echo htmlspecialchars($cliente['nombre']); ?></td>
                <td><?php echo htmlspecialchars($cliente['empresa']); ?></td>
                <td><?php echo htmlspecialchars($cliente['email']); ?></td>
                <td><?php echo htmlspecialchars($cliente['telefono']); ?></td>
                <td>
                    <a href="editar_cliente.php?id=<?php echo $cliente['id']; ?>" class="btn btn-primary btn-sm">Editar</a>
                    <a href="ver_cliente.php?id=<?php echo $cliente['id']; ?>" class="btn btn-info btn-sm">Ver</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    
    <a href="agregar_cliente.php" class="btn btn-success">Agregar Nuevo Cliente</a>
</div>

<?php include 'layout_footer.php'; ?>






