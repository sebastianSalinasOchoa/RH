<?php
session_start();
require 'db_connect.php';
require 'layout_header.php';

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Función para calcular días hasta vencimiento o días vencidos
function calcularDiasVencimiento($fecha_finalizacion) {
    if ($fecha_finalizacion === null || $fecha_finalizacion === 'indefinido') {
        return ['dias' => 'N/A', 'clase' => 'indefinido'];
    }
    $hoy = new DateTime();
    $fecha_fin = new DateTime($fecha_finalizacion);
    $diferencia = $hoy->diff($fecha_fin);
    $dias = $diferencia->days;
    $signo = $hoy > $fecha_fin ? -1 : 1;
    $dias_reales = $dias * $signo;

    if ($dias_reales < 0) {
        return ['dias' => "Vencido hace " . abs($dias_reales) . " días", 'clase' => 'vencido'];
    } elseif ($dias_reales == 0) {
        return ['dias' => "Vence hoy", 'clase' => 'vence-hoy'];
    } elseif ($dias_reales <= 30) {
        return ['dias' => "Faltan " . $dias_reales . " días", 'clase' => 'proximo-a-vencer'];
    } else {
        return ['dias' => "Faltan " . $dias_reales . " días", 'clase' => 'vigente'];
    }
}

// Función para actualizar el estado del contrato
function actualizarEstadoContrato($pdo, $contrato_id, $nuevo_estado) {
    $stmt = $pdo->prepare("UPDATE contratos SET estado = ? WHERE id = ?");
    $stmt->execute([$nuevo_estado, $contrato_id]);
}

// Obtener la lista de contratos
$stmt = $pdo->query("
    SELECT c.* 
    FROM contratos c
    ORDER BY c.fecha_inicio DESC
");
$contratos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Actualizar estados y calcular días para vencer
$hoy = new DateTime();
foreach ($contratos as &$contrato) {
    if ($contrato['tipo_contrato'] == 'indefinido') {
        $contrato['estado'] = 'Vigente';
        $contrato['dias_vencimiento'] = calcularDiasVencimiento(null);
    } else {
        $fecha_fin = new DateTime($contrato['fecha_finalizacion']);
        if ($hoy > $fecha_fin) {
            $contrato['estado'] = 'Vencido';
        } else {
            $contrato['estado'] = 'Vigente';
        }
        $contrato['dias_vencimiento'] = calcularDiasVencimiento($contrato['fecha_finalizacion']);
    }
    actualizarEstadoContrato($pdo, $contrato['id'], $contrato['estado']);
}

// Render header
renderHeader('Ver Contratos');
?>

<div class="container">
    <h1>Lista de Contratos</h1>

    <style>
        .vencido { color: red; font-weight: bold; }
        .vence-hoy { color: orange; font-weight: bold; }
        .proximo-a-vencer { color: yellow; font-weight: bold; }
        .vigente { color: green; }
        .indefinido { color: blue; }
    </style>

    <table class="table">
        <thead>
            <tr>
                <th>Trabajador</th>
                <th>Fecha de Inicio</th>
                <th>Fecha de Fin</th>
                <th>Tipo de Contrato</th>
                <th>Días para vencer / vencido</th>
                <th>Estado</th>
                <th>Puesto</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($contratos as $contrato): ?>
            <tr>
                <td><?php echo htmlspecialchars($contrato['nombre_colaborador']); ?></td>
                <td><?php echo htmlspecialchars($contrato['fecha_inicio']); ?></td>
                <td><?php echo $contrato['fecha_finalizacion'] === 'indefinido' ? 'Indefinido' : htmlspecialchars($contrato['fecha_finalizacion']); ?></td>
                <td><?php echo ucfirst($contrato['tipo_contrato'] ?? 'No especificado'); ?></td>
                <td class="<?php echo $contrato['dias_vencimiento']['clase']; ?>">
                    <?php echo $contrato['dias_vencimiento']['dias']; ?>
                </td>
                <td class="<?php echo $contrato['estado'] == 'Vigente' ? 'estado-vigente' : 'estado-vencido'; ?>">
                    <?php echo htmlspecialchars($contrato['estado']); ?>
                </td>
                <td><?php echo htmlspecialchars($contrato['puesto']); ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="mt-4">
        <a href="gestionar_contratos.php" class="btn btn-primary">Crear Nuevo Contrato</a>
    </div>
</div>

<?php include 'layout_footer.php'; ?>





