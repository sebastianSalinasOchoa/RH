<?php
session_start();
require 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['tipo'] != 'rh') {
    header('Location: login.php');
    exit;
}

$username = $_SESSION['username'] ?? 'Usuario RH';
$user_id = $_SESSION['user_id'];

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Coordinación - RH</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="layout">
        <aside class="sidebar">
            <h1 class="text-center mb-4">Sistema RH</h1>
            <nav>
                <ul class="nav-menu">
                    <li class="nav-item">
                        <a href="dashboard.php" class="nav-link">
                            <i class="fas fa-tachometer-alt"></i> Panel de Control
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="gestionar_solicitudes.php" class="nav-link">
                            <i class="fas fa-tasks"></i> Gestionar Solicitudes
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="agregar_solicitud.php" class="nav-link">
                            <i class="fas fa-plus-circle"></i> Agregar Solicitud
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="gestionar_clientes.php" class="nav-link">
                            <i class="fas fa-users"></i> Gestionar Clientes
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="gestionar_trabajadores.php" class="nav-link">
                            <i class="fas fa-hard-hat"></i> Gestionar Trabajadores
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="gestionar_contratos.php" class="nav-link">
                            <i class="fas fa-file-contract"></i> Gestionar Contratos
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="listar_trabajadores.php" class="nav-link">
                            <i class="fas fa-list"></i> Listado de Trabajadores
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="reportes_analisis.php" class="nav-link">
                            <i class="fas fa-chart-bar"></i> Reportes y Análisis
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="logout.php" class="nav-link">
                            <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>
        <main class="main-content">
            <div class="container">
                <h2>Bienvenido, <?php echo htmlspecialchars($username); ?></h2>
                <div class="card mt-4">
                    <h3>Resumen del Sistema</h3>
                    <p>Selecciona una opción del menú para comenzar a gestionar el sistema de coordinación.</p>
                </div>
                <!-- Aquí puedes agregar widgets o resúmenes rápidos si lo deseas -->
            </div>
        </main>
    </div>
</body>
</html>


