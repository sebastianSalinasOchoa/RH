<?php
session_start();
require 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$mensaje = '';

// Obtener información del usuario
$stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
$stmt->execute([$user_id]);
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $telefono = $_POST['telefono'];
    $empresa = $_POST['empresa'];
    $nueva_password = $_POST['nueva_password'];

    try {
        if (!empty($nueva_password)) {
            // Actualizar con nueva contraseña
            $hashed_password = password_hash($nueva_password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE usuarios SET username = ?, email = ?, telefono = ?, empresa = ?, password = ? WHERE id = ?");
            $stmt->execute([$nombre, $email, $telefono, $empresa, $hashed_password, $user_id]);
        } else {
            // Actualizar sin cambiar la contraseña
            $stmt = $pdo->prepare("UPDATE usuarios SET username = ?, email = ?, telefono = ?, empresa = ? WHERE id = ?");
            $stmt->execute([$nombre, $email, $telefono, $empresa, $user_id]);
        }
        $mensaje = "Perfil actualizado con éxito.";
        
        // Actualizar la información en la sesión
        $_SESSION['username'] = $nombre;
    } catch (PDOException $e) {
        $mensaje = "Error al actualizar el perfil: " . $e->getMessage();
    }
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Perfil</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Mi Perfil</h1>
        
        <?php if ($mensaje): ?>
            <p class="mensaje"><?php echo htmlspecialchars($mensaje); ?></p>
        <?php endif; ?>

        <form method="POST" class="form-perfil">
            <div>
                <label for="nombre">Nombre:</label>
                <input type="text" id="nombre" name="nombre" value="<?php echo htmlspecialchars($usuario['username']); ?>" required>
            </div>
            <div>
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($usuario['email']); ?>" required>
            </div>
            <div>
                <label for="telefono">Teléfono:</label>
                <input type="tel" id="telefono" name="telefono" value="<?php echo htmlspecialchars($usuario['telefono']); ?>">
            </div>
            <div>
                <label for="empresa">Empresa:</label>
                <input type="text" id="empresa" name="empresa" value="<?php echo htmlspecialchars($usuario['empresa']); ?>">
            </div>
            <div>
                <label for="nueva_password">Nueva Contraseña (dejar en blanco para no cambiar):</label>
                <input type="password" id="nueva_password" name="nueva_password">
            </div>
            <button type="submit">Actualizar Perfil</button>
        </form>
        
        <a href="index.php" class="button">Volver al inicio</a>
    </div>
</body>
</html>

