<?php
session_start();
require 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$mensaje_id = $_GET['id'] ?? null;

if (!$mensaje_id) {
    header('Location: mensajeria.php');
    exit;
}

// Obtener el mensaje
$stmt = $pdo->prepare("SELECT m.*, u.username as remitente_nombre 
                       FROM mensajes m 
                       JOIN usuarios u ON m.remitente_id = u.id 
                       WHERE m.id = ? AND m.destinatario_id = ?");
$stmt->execute([$mensaje_id, $user_id]);
$mensaje = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$mensaje) {
    header('Location: mensajeria.php');
    exit;
}

// Marcar el mensaje como leído
if (!$mensaje['leido']) {
    $stmt = $pdo->prepare("UPDATE mensajes SET leido = TRUE WHERE id = ?");
    $stmt->execute([$mensaje_id]);
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver Mensaje</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Ver Mensaje</h1>

        <div class="mensaje-detalle">
            <p><strong>De:</strong> <?php echo htmlspecialchars($mensaje['remitente_nombre']); ?></p>
            <p><strong>Fecha:</strong> <?php echo $mensaje['fecha_envio']; ?></p>
            <p><strong>Asunto:</strong> <?php echo htmlspecialchars($mensaje['asunto']); ?></p>
            <div class="mensaje-contenido">
                <p><?php echo nl2br(htmlspecialchars($mensaje['contenido'])); ?></p>
            </div>
        </div>

        <a href="mensajeria.php" class="button">Volver a Mensajes</a>
        <a href="index.php" class="button">Volver al inicio</a>
    </div>
</body>
</html>

