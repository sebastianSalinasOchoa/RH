<aside class="sidebar">
    <h1 class="text-center mb-4">Sistema RH</h1>
    <nav>
        <ul class="nav-menu">
            <li class="nav-item">
                <a href="dashboard.php" class="nav-link">
                    <i class="fas fa-tachometer-alt"></i> Panel de Control
                </a>
            </li>
            <?php if (tienePermiso('gestionar_solicitudes')): ?>
            <li class="nav-item">
                <a href="gestionar_solicitudes.php" class="nav-link">
                    <i class="fas fa-tasks"></i> Gestionar Solicitudes
                </a>
            </li>
            <?php endif; ?>
            <?php if (tienePermiso('gestionar_trabajadores')): ?>
            <li class="nav-item">
                <a href="gestionar_trabajadores.php" class="nav-link">
                    <i class="fas fa-hard-hat"></i> Gestionar Trabajadores
                </a>
            </li>
            <?php endif; ?>
            <?php if (tienePermiso('gestionar_contratos')): ?>
            <li class="nav-item">
                <a href="gestionar_contratos.php" class="nav-link">
                    <i class="fas fa-file-contract"></i> Gestionar Contratos
                </a>
            </li>
            <?php endif; ?>
            <?php if (tienePermiso('ver_reportes')): ?>
            <li class="nav-item">
                <a href="reportes_analisis.php" class="nav-link">
                    <i class="fas fa-chart-bar"></i> Reportes y Análisis
                </a>
            </li>
            <?php endif; ?>
            <?php if ($_SESSION['rol'] === 'admin'): ?>
            <li class="nav-item">
                <a href="admin_usuarios.php" class="nav-link">
                    <i class="fas fa-users-cog"></i> Administrar Usuarios
                </a>
            </li>
            <?php endif; ?>
            <li class="nav-item">
                <a href="logout.php" class="nav-link">
                    <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
                </a>
            </li>
        </ul>
    </nav>
</aside>

