<?php
session_start();
require 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['rol'] != 'coordinador') {
    header('Location: index.php');
    exit;
}

$stmt = $pdo->query('SELECT p.*, u.username FROM peticiones p JOIN usuarios u ON p.usuario_id = u.id WHERE p.estado = "pendiente"');
$peticiones = $stmt->fetchAll();

$stmt = $pdo->query('SELECT * FROM trabajadores');
$trabajadores = $stmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $peticion_id = $_POST['peticion_id'];
    $trabajador_id = $_POST['trabajador_id'];
    $fecha_asignacion = $_POST['fecha_asignacion'];
    $hora_inicio = $_POST['hora_inicio'];
    $hora_fin = $_POST['hora_fin'];

    $stmt = $pdo->prepare('INSERT INTO asignaciones (peticion_id, trabajador_id, fecha_asignacion, hora_inicio, hora_fin) VALUES (?, ?, ?, ?, ?)');
    $stmt->execute([$peticion_id, $trabajador_id, $fecha_asignacion, $hora_inicio, $hora_fin]);

    $stmt = $pdo->prepare('UPDATE peticiones SET estado = "completada" WHERE id = ?');
    $stmt->execute([$peticion_id]);

    $mensaje = 'Petición completada con éxito';
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Peticiones Pendientes</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Peticiones Pendientes</h1>
        <?php if (isset($mensaje)): ?>
            <p class="mensaje"><?php echo $mensaje; ?></p>
        <?php endif; ?>
        <?php foreach ($peticiones as $peticion): ?>
            <div class="peticion">
                <h2>Petición #<?php echo $peticion['id']; ?></h2>
                <p><strong>Solicitante:</strong> <?php echo $peticion['username']; ?></p>
                <p><strong>Descripción:</strong> <?php echo $peticion['descripcion']; ?></p>
                <form method="POST">
                    <input type="hidden" name="peticion_id" value="<?php echo $peticion['id']; ?>">
                    <div>
                        <label for="trabajador_id">Asignar trabajador:</label>
                        <select id="trabajador_id" name="trabajador_id" required>
                            <?php foreach ($trabajadores as $trabajador): ?>
                                <option value="<?php echo $trabajador['id']; ?>"><?php echo $trabajador['nombre']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label for="fecha_asignacion">Fecha de asignación:</label>
                        <input type="date" id="fecha_asignacion" name="fecha_asignacion" required>
                    </div>
                    <div>
                        <label for="hora_inicio">Hora de inicio:</label>
                        <input type="time" id="hora_inicio" name="hora_inicio" required>
                    </div>
                    <div>
                        <label for="hora_fin">Hora de fin:</label>
                        <input type="time" id="hora_fin" name="hora_fin" required>
                    </div>
                    <button type="submit">Completar Petición</button>
                </form>
            </div>
        <?php endforeach; ?>
        <a href="index.php">Volver al inicio</a>
    </div>
</body>
</html>