<?php
session_start();
require 'db_connect.php';
require 'layout_header.php';

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$mensaje = '';
$error = '';

// Función para actualizar el estado de los contratos
function actualizarEstadoContratos($pdo) {
    $stmt = $pdo->prepare("
        UPDATE contratos 
        SET estado = 'finalizado' 
        WHERE fecha_finalizacion IS NOT NULL 
        AND fecha_finalizacion <= CURDATE() 
        AND estado != 'finalizado'
    ");
    $stmt->execute();
}

// Procesar el formulario cuando se envía
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre_colaborador = $_POST['nombre_colaborador'] ?? '';
    $cedula = $_POST['cedula'] ?? '';
    $telefono = $_POST['telefono'] ?? '';
    $puesto = $_POST['puesto'] ?? '';
    $lugar_trabajo = $_POST['lugar_trabajo'] ?? '';
    $fecha_inicio = $_POST['fecha_inicio'] ?? '';
    $tipo_contrato = $_POST['tipo_contrato'] ?? '';
    $fecha_finalizacion = ($tipo_contrato === 'definido') ? ($_POST['fecha_finalizacion'] ?? '') : null;
    $es_indefinido = ($tipo_contrato === 'indefinido') ? 1 : 0;
    $estado = ($tipo_contrato === 'indefinido') ? 'indefinido' : 'activo';
    $usuario_registro = $_SESSION['username'];

    if (empty($nombre_colaborador) || empty($cedula) || empty($telefono) || empty($puesto) || empty($lugar_trabajo) || empty($fecha_inicio) || empty($tipo_contrato)) {
        $error = "Por favor, complete todos los campos requeridos.";
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO contratos (nombre_colaborador, cedula, telefono, puesto, lugar_trabajo, fecha_inicio, fecha_finalizacion, es_indefinido, estado, usuario_registro) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$nombre_colaborador, $cedula, $telefono, $puesto, $lugar_trabajo, $fecha_inicio, $fecha_finalizacion, $es_indefinido, $estado, $usuario_registro]);
            $mensaje = "Contrato registrado exitosamente.";
        } catch(PDOException $e) {
            $error = "Error al registrar el contrato: " . $e->getMessage();
        }
    }
}

// Actualizar el estado de los contratos
actualizarEstadoContratos($pdo);

// Obtener la lista de contratos
$stmt = $pdo->query("
    SELECT * FROM contratos
    ORDER BY fecha_inicio DESC
");
$contratos = $stmt->fetchAll();

// Render header
renderHeader('Gestionar Contratos');
?>

<div class="container">
    <h1>Gestionar Contratos</h1>

    <?php if ($mensaje): ?>
        <div class="alert alert-success"><?php echo htmlspecialchars($mensaje); ?></div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <h2>Crear Nuevo Contrato</h2>
    <form method="POST" class="form-contrato">
        <div class="form-group">
            <label for="nombre_colaborador">Nombre del Colaborador:</label>
            <input type="text" name="nombre_colaborador" id="nombre_colaborador" class="form-input" required>
        </div>

        <div class="form-group">
            <label for="cedula">Cédula:</label>
            <input type="text" name="cedula" id="cedula" class="form-input" required>
        </div>

        <div class="form-group">
            <label for="telefono">Teléfono:</label>
            <input type="text" name="telefono" id="telefono" class="form-input" required>
        </div>

        <div class="form-group">
            <label for="puesto">Puesto:</label>
            <input type="text" name="puesto" id="puesto" class="form-input" required>
        </div>

        <div class="form-group">
            <label for="lugar_trabajo">Lugar de Trabajo:</label>
            <input type="text" name="lugar_trabajo" id="lugar_trabajo" class="form-input" required>
        </div>

        <div class="form-group">
            <label for="fecha_inicio">Fecha de Inicio:</label>
            <input type="date" name="fecha_inicio" id="fecha_inicio" class="form-input" required>
        </div>

        <div class="form-group">
            <label for="tipo_contrato">Tipo de Contrato:</label>
            <select name="tipo_contrato" id="tipo_contrato" class="form-input" required onchange="toggleFechaFinalizacion()">
                <option value="">Seleccione el tipo de contrato</option>
                <option value="definido">Definido</option>
                <option value="indefinido">Indefinido</option>
            </select>
        </div>

        <div class="form-group" id="fecha_finalizacion_container">
            <label for="fecha_finalizacion">Fecha de Finalización:</label>
            <input type="date" name="fecha_finalizacion" id="fecha_finalizacion" class="form-input">
        </div>

        <button type="submit" class="btn btn-primary">Registrar Contrato</button>
    </form>

    <h2 class="mt-4">Lista de Contratos</h2>
    <table class="table">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Cédula</th>
                <th>Puesto</th>
                <th>Lugar de Trabajo</th>
                <th>Fecha de Inicio</th>
                <th>Fecha de Finalización</th>
                <th>Estado</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($contratos as $contrato): ?>
            <tr>
                <td><?php echo htmlspecialchars($contrato['nombre_colaborador']); ?></td>
                <td><?php echo htmlspecialchars($contrato['cedula']); ?></td>
                <td><?php echo htmlspecialchars($contrato['puesto']); ?></td>
                <td><?php echo htmlspecialchars($contrato['lugar_trabajo']); ?></td>
                <td><?php echo htmlspecialchars($contrato['fecha_inicio']); ?></td>
                <td><?php echo $contrato['es_indefinido'] ? 'Indefinido' : htmlspecialchars($contrato['fecha_finalizacion']); ?></td>
                <td><?php echo htmlspecialchars($contrato['estado']); ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script>
function toggleFechaFinalizacion() {
    const tipoContrato = document.getElementById('tipo_contrato').value;
    const fechaFinalizacionContainer = document.getElementById('fecha_finalizacion_container');
    const fechaFinalizacionInput = document.getElementById('fecha_finalizacion');

    if (tipoContrato === 'indefinido') {
        fechaFinalizacionContainer.style.display = 'none';
        fechaFinalizacionInput.removeAttribute('required');
        fechaFinalizacionInput.value = '';
    } else {
        fechaFinalizacionContainer.style.display = 'block';
        fechaFinalizacionInput.setAttribute('required', 'required');
    }
}

// Ejecutar al cargar la página
document.addEventListener('DOMContentLoaded', toggleFechaFinalizacion);
</script>

<?php include 'layout_footer.php'; ?>



